﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace informationtest
{
    public partial class zd1 : Form
    {
        public zd1()
        {
            InitializeComponent();
            PictureBoxGeneration();
            ((Control)pictureBox1).AllowDrop = true;
            ((Control)pictureBox2).AllowDrop = true;
            ((Control)pictureBox3).AllowDrop = true;
            ((Control)pictureBox4).AllowDrop = true;
            ((Control)pictureBox5).AllowDrop = true;
            ((Control)pictureBox6).AllowDrop = true;
            ((Control)pictureBox7).AllowDrop = true;
            ((Control)pictureBox8).AllowDrop = true;
        }
        private Image m_imgSave;
        int from_picbox = 0;
        private struct ImageTestVariable
        {
            public Image m_image { get; set; }
            public int index { get; set; }
        }
        List<ImageTestVariable> arr = new List<ImageTestVariable>();
        public void PictureBoxGeneration()
        {
            int aye = 0;
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._2_бит, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1_байт, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._12_бит, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1000_байт, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1_килобайт, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._0_5кб, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._512r_, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._514кб, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._0_5_мбайт, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1026Мбайт, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1_тб, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1030Гб, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = null, index = ++aye });

            Random random = new Random();
            for (int i = 12 - 1; i >= 1; i--)
            {
                int j = random.Next(i + 1);
                var temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }

            //arr[0].pic = 1;
            pictureBox1.Image = arr[0].m_image;
            pictureBox2.Image = arr[1].m_image;
            pictureBox3.Image = arr[2].m_image;
            pictureBox4.Image = arr[3].m_image;
            pictureBox5.Image = arr[4].m_image;
            pictureBox6.Image = arr[5].m_image;
            pictureBox7.Image = arr[6].m_image;
            pictureBox8.Image = arr[7].m_image;

        }
        //DragEnter для picturebox
        private void pictureBox1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;

            
            
        }
        private void pictureBox2_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
           
        }

        private void pictureBox3_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox4_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox5_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox6_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox7_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox8_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }
        
        private void pictureBox1_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            m_imgSave = pictureBox1.Image;
            SetImageToPicBox();
            pictureBox1.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox2_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            m_imgSave = pictureBox2.Image;
            SetImageToPicBox();
            pictureBox2.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox3_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            m_imgSave = pictureBox3.Image;
            SetImageToPicBox();
            pictureBox3.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox4_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            m_imgSave = pictureBox4.Image;
            SetImageToPicBox();
            pictureBox4.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox5_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            m_imgSave = pictureBox5.Image;
            SetImageToPicBox();
            pictureBox5.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox6_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            m_imgSave = pictureBox6.Image;
            SetImageToPicBox();
            pictureBox6.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox7_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            m_imgSave = pictureBox7.Image;
            SetImageToPicBox();
            pictureBox7.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox8_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            m_imgSave = pictureBox8.Image;
            SetImageToPicBox();
            pictureBox8.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }


      
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            from_picbox = 1;
            if (DoDragDrop(pictureBox1.Image, DragDropEffects.Move) == DragDropEffects.Move){}

        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            from_picbox = 2;
            if (DoDragDrop(pictureBox2.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            from_picbox = 3;
            if (DoDragDrop(pictureBox3.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox4_MouseDown(object sender, MouseEventArgs e)
        {
            from_picbox = 4;
            if (DoDragDrop(pictureBox4.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox5_MouseDown(object sender, MouseEventArgs e)
        {
            from_picbox = 5;
            if (DoDragDrop(pictureBox5.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox6_MouseDown(object sender, MouseEventArgs e)
        {
            from_picbox = 6;
            if (DoDragDrop(pictureBox6.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox7_MouseDown(object sender, MouseEventArgs e)
        {
            from_picbox = 7;
            if (DoDragDrop(pictureBox7.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox8_MouseDown(object sender, MouseEventArgs e)
        {
            from_picbox = 8;
            if (DoDragDrop(pictureBox8.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        public void Save_Image()
        {

            if (
                pictureBox1.Image == arr[0].m_image &&
                pictureBox2.Image == arr[1].m_image &&
                pictureBox3.Image == arr[2].m_image &&
                pictureBox4.Image == arr[3].m_image &&
                pictureBox5.Image == arr[4].m_image &&
                pictureBox6.Image == arr[5].m_image &&
                pictureBox7.Image == arr[6].m_image &&
                pictureBox8.Image == arr[7].m_image
                )
            {
                MessageBox.Show("OK");
            }
        }

        void SetImageToPicBox()
        {
            switch (from_picbox)
            {
                case 1:
                    pictureBox1.Image = m_imgSave;
                    break;
                case 2:
                    pictureBox2.Image = m_imgSave;
                    break;
                case 3:
                    pictureBox3.Image = m_imgSave;
                    break;
                case 4:
                    pictureBox4.Image = m_imgSave;
                    break;
                case 5:
                    pictureBox5.Image = m_imgSave;
                    break;
                case 6:
                    pictureBox6.Image = m_imgSave;
                    break;
                case 7:
                    pictureBox7.Image = m_imgSave;
                    break;
                case 8:
                    pictureBox8.Image = m_imgSave;
                    break;
                default:
                    break;
            }
        }

        
    }
}
