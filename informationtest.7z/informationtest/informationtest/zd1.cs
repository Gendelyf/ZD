﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace informationtest
{
    public partial class zd1 : Form
    {
        public zd1()
        {
            InitializeComponent();
            PictureBoxGeneration();
            ((Control)pictureBox1).AllowDrop = true;
            ((Control)pictureBox2).AllowDrop = true;
            ((Control)pictureBox3).AllowDrop = true;
            ((Control)pictureBox4).AllowDrop = true;
            ((Control)pictureBox5).AllowDrop = true;
            ((Control)pictureBox6).AllowDrop = true;
            ((Control)pictureBox7).AllowDrop = true;
            ((Control)pictureBox8).AllowDrop = true;
        }
        public int index;
        private struct ImageTestVariable
        {
            public Image m_image { get; set; }
            public int index { get; set; }
        }
        public void PictureBoxGeneration()
        {
            
            List<ImageTestVariable> arr = new List<ImageTestVariable>();
            int aye = 0;
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._2_бит, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1_байт, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._12_бит, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1000_байт, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1_килобайт, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._0_5кб, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._512r_, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._514кб, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._0_5_мбайт, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1026Мбайт, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1_тб, index = ++aye });
            arr.Add(new ImageTestVariable { m_image = Properties.Resources._1030Гб, index = ++aye });

            Random random = new Random();
            for (int i = arr.Count - 1; i >= 1; i--)
            {
                int j = random.Next(i + 1);
                var temp = arr[j];
                arr[j] = arr[i];
                arr[i] = temp;
            }

            //arr[0].pic = 1;
            pictureBox1.Image = arr[0].m_image;
            pictureBox2.Image = arr[1].m_image;
            pictureBox3.Image = arr[2].m_image;
            pictureBox4.Image = arr[3].m_image;
            pictureBox5.Image = arr[4].m_image;
            pictureBox6.Image = arr[5].m_image;
            pictureBox7.Image = arr[6].m_image;
            pictureBox8.Image = arr[7].m_image;


        }
        //DragEnter для picturebox
        private void pictureBox1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
            index = 0;
        }
        private void pictureBox2_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
            index = 1;
        }

        private void pictureBox3_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }
        private void pictureBox8_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox1_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            pictureBox2.Image = bmp;
        }

        private void pictureBox2_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            pictureBox2.Image = bmp;
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            var img = pictureBox1.Image;
            if (img == null) return;
            
        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            var img = pictureBox2.Image;
            if (img == null) return;
            if (DoDragDrop(img, DragDropEffects.Move) == DragDropEffects.Move)
            {
                pictureBox2.Image = null;
            }
        }
    }
}
