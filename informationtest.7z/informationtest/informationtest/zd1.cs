﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace informationtest
{
    public partial class zd1 : Form
    {
        public zd1()
        {
            InitializeComponent();
            
        }
        public void Random()
        {
            Random rnd = new Random();
            h:
            for(int pb =0;pb<=8;)
            {
                int 
                int move =
                goto h;
            }
        }


    }
}
