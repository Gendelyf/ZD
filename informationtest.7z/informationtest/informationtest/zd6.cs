﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace informationtest
{
    public partial class zd6 : Form
    {
        public zd6()
        {
            InitializeComponent();
            zd5 ZD5 = new zd5();
            label1.Text = ($"Отметка:{ZD5.total_point}");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
