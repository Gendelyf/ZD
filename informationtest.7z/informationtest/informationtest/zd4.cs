﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace informationtest
{
    public partial class zd4 : Form
    {
        public zd4()
        {
            InitializeComponent();
           
            ((Control)pictureBox2).AllowDrop = true;
            ((Control)pictureBox3).AllowDrop = true;
            ((Control)pictureBox4).AllowDrop = true;
            ((Control)pictureBox5).AllowDrop = true;
            ((Control)pictureBox6).AllowDrop = true;
            ((Control)pictureBox7).AllowDrop = true;
            ((Control)pictureBox8).AllowDrop = true;
            ((Control)pictureBox9).AllowDrop = true;
            ((Control)pictureBox10).AllowDrop = true;
            ((Control)pictureBox11).AllowDrop = true;
            ((Control)pictureBox12).AllowDrop = true;
            ((Control)pictureBox13).AllowDrop = true;
            ((Control)pictureBox14).AllowDrop = true;
            ((Control)pictureBox15).AllowDrop = true;
            ((Control)pictureBox16).AllowDrop = true;
            ((Control)pictureBox17).AllowDrop = true;
            ((Control)pictureBox18).AllowDrop = true;
            ((Control)pictureBox19).AllowDrop = true;
            ((Control)pictureBox20).AllowDrop = true;

        }
        private Image m_imgSave;
        int from_picbox = 0;
        //void SetImageToPicBox()
        //{
        //    switch (from_picbox)
        //    {
        //        case 2:
        //            pictureBox2.Image = m_imgSave;
        //            break;
        //        case 3:
        //            pictureBox3.Image = m_imgSave;
        //            break;
               
        //    }
        //}
       
        private void pictureBox2_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox4_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox20_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }


        private void pictureBox21_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox22_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox2_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox4_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox20_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox21_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox22_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox2_MouseDown(object sender, MouseEventArgs e)
        {
            if (DoDragDrop(pictureBox2.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox4_MouseDown(object sender, MouseEventArgs e)
        {
            if (DoDragDrop(pictureBox4.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox20_MouseDown(object sender, MouseEventArgs e)
        {
            if (DoDragDrop(pictureBox20.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox21_MouseDown(object sender, MouseEventArgs e)
        {
            if (DoDragDrop(pictureBox21.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox22_MouseDown(object sender, MouseEventArgs e)
        {
            if (DoDragDrop(pictureBox22.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox3_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            pictureBox3.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }
        private void pictureBox5_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            pictureBox5.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox6_DragDrop(object sender, DragEventArgs e)
        {
            var bmp = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            pictureBox6.Image = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
        }

        private void pictureBox3_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox5_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox6_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
                e.Effect = DragDropEffects.Move;
        }

        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            if (DoDragDrop(pictureBox3.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }
        private void pictureBox5_MouseDown(object sender, MouseEventArgs e)
        {
            if (DoDragDrop(pictureBox5.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }

        private void pictureBox6_MouseDown(object sender, MouseEventArgs e)
        {
            if (DoDragDrop(pictureBox6.Image, DragDropEffects.Move) == DragDropEffects.Move) { }
        }
        
       
    }
}
