﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace informationtest
{
    public partial class zd4 : Form
    {
        public zd4()
        {
            InitializeComponent();
            ((Control)label1).AllowDrop = true;
            ((Control)label2).AllowDrop = true;
            ((Control)label3).AllowDrop = true;
            ((Control)label4).AllowDrop = true;
            ((Control)label5).AllowDrop = true;
            ((Control)label6).AllowDrop = true;
            ((Control)label7).AllowDrop = true;
            ((Control)label8).AllowDrop = true;
            ((Control)label9).AllowDrop = true;
            ((Control)label10).AllowDrop = true;
            ((Control)label11).AllowDrop = true;
            ((Control)label12).AllowDrop = true;
            ((Control)label13).AllowDrop = true;
            ((Control)label14).AllowDrop = true;
            ((Control)label15).AllowDrop = true;
            ((Control)label16).AllowDrop = true;
            ((Control)label17).AllowDrop = true;
            ((Control)label18).AllowDrop = true;
            ((Control)label19).AllowDrop = true;
            ((Control)label20).AllowDrop = true;
            ((Control)label21).AllowDrop = true;
            ((Control)label22).AllowDrop = true;
            ((Control)label23).AllowDrop = true;
            ((Control)label24).AllowDrop = true;
            ((Control)label25).AllowDrop = true;
            ((Control)label26).AllowDrop = true;
            ((Control)label27).AllowDrop = true;
        }
        public string text;
        private void zd4_Resize(object sender, EventArgs e)
        {
           
        }

        private void label17_MouseDown(object sender, MouseEventArgs e)
        {
            label17.DoDragDrop(label17.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label18_MouseDown(object sender, MouseEventArgs e)
        {
            label18.DoDragDrop(label18.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label19_MouseDown(object sender, MouseEventArgs e)
        {
            label19.DoDragDrop(label19.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label20_MouseDown(object sender, MouseEventArgs e)
        {
            label20.DoDragDrop(label20.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label21_MouseDown(object sender, MouseEventArgs e)
        {
            label21.DoDragDrop(label21.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label22_MouseDown(object sender, MouseEventArgs e)
        {
            label22.DoDragDrop(label22.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label23_MouseDown(object sender, MouseEventArgs e)
        {
            label23.DoDragDrop(label23.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label24_MouseDown(object sender, MouseEventArgs e)
        {
            label24.DoDragDrop(label24.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label25_MouseDown(object sender, MouseEventArgs e)
        {
            label25.DoDragDrop(label25.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label26_MouseDown(object sender, MouseEventArgs e)
        {
            label26.DoDragDrop(label26.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label27_MouseDown(object sender, MouseEventArgs e)
        {
            label27.DoDragDrop(label27.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }






        private void label14_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label14.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label13_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label13.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label12_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label12.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label11_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label11.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label9_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label9.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label10_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label10.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label2_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label2.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label3_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label3.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label4_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label4.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label5_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label5.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label1_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label1.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label7_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label7.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label6_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label6.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label8_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label8.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label15_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label15.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label16_DragDrop(object sender, DragEventArgs e)
        {
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label16.Text = (string)e.Data.GetData(DataFormats.StringFormat);
        }

        private void label14_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label13_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label12_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label15_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label16_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label6_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label8_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label7_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label2_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label9_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label3_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label4_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label5_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label10_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label11_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }
        public int point4;
        private void button1_Click(object sender, EventArgs e)
        {
            if(label2.Text =="Games" && 
              label3.Text == "myst.exe" &&
              label9.Text == "FPS" && 
              ((label10.Text == "doom.exe" && label11.Text == "quake.exe") ||
             ( label10.Text == "quake.exe" && label11.Text == "doom.exe")) &&
              label4.Text == "Strategy" &&
              label5.Text == "duna.exe" &&
              label1.Text == "doom.exe"&&
              label6.Text == "Strategy"&&
              (label7.Text == "elite.exe"&& label8.Text == "duna.exe" ||
               label8.Text == "elite.exe" && label7.Text == "duna.exe") &&
               label15.Text == "Quest"&&
               label16.Text == "myst.exe"&&
               label12.Text =="FPS"&&
               label13.Text == "Hexen" &&
               label14.Text == "hexen.exe"
              )
            {
                point4 = 1;
                zd5 zd = new zd5();
                this.Hide();
                zd.ShowDialog();
            }

        }
    }
}
