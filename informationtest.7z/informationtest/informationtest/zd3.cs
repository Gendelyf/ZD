﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace informationtest
{
    public partial class zd3 : Form
    {
        private struct Text_label
        {
            public string text { get; set; }
            public int number { get; set; }
            public int znach { get; set; }
        }
        public int point;
        private struct LabelList
        {
            public Label label { get; set; }
        }
        List<Text_label> TL = new List<Text_label>();
        List<LabelList> LL = new List<LabelList>();
        public Random rnd = new Random();
        public string text1;
        public string text2;
        public int lb1;
        public int lb2;
        public int prow = 0;
        public int index;
        public int index2;
        public zd3()
        {
            InitializeComponent();
            LL.Add(new LabelList { label = label1});
            LL.Add(new LabelList { label = label2 });
            LL.Add(new LabelList { label = label3 });
            LL.Add(new LabelList { label = label4 });
            LL.Add(new LabelList { label = label5 });
            LL.Add(new LabelList { label = label6 });
            LL.Add(new LabelList { label = label7 });
            LL.Add(new LabelList { label = label8 });
            LL.Add(new LabelList { label = label9 });
            LL.Add(new LabelList { label = label10 });
            LL.Add(new LabelList { label = label11 });
            LL.Add(new LabelList { label = label12 });
            LL.Add(new LabelList { label = label13 });
            LL.Add(new LabelList { label = label14 });
            LL.Add(new LabelList { label = label15 });
            LL.Add(new LabelList { label = label16 });
            LL.Add(new LabelList { label = label17 });
            LL.Add(new LabelList { label = label18 });
            LL.Add(new LabelList { label = label19 });
            LL.Add(new LabelList { label = label20 });
            LL.Add(new LabelList { label = label21 });
            LL.Add(new LabelList { label = label22 });
            LL.Add(new LabelList { label = label23 });
            LL.Add(new LabelList { label = label24 });
            LL.Add(new LabelList { label = label25});
            LL.Add(new LabelList { label = label26 });
            LL.Add(new LabelList { label = label27 });
            LL.Add(new LabelList { label = label28 });
            LL.Add(new LabelList { label = label29 });
            LL.Add(new LabelList { label = label30 });
            LL.Add(new LabelList { label = label31 });
            LL.Add(new LabelList { label = label32 });
            LL.Add(new LabelList { label = label33 });
            LL.Add(new LabelList { label = label34 });
            LL.Add(new LabelList { label = label35 });
            LL.Add(new LabelList { label = label36 });
            LL.Add(new LabelList { label = label37 });
            LL.Add(new LabelList { label = label38 });
            LL.Add(new LabelList { label = label39 });
            LL.Add(new LabelList { label = label40 });
            TL.Add(new Text_label { text = "графический",number =0,znach =1 });
            TL.Add(new Text_label { text = "интерфейс",number =0, znach = 2 });
            TL.Add(new Text_label { text = "DVD", number = 0, znach = 3 });
            TL.Add(new Text_label { text = "дисковод", number = 0, znach = 4 });
            TL.Add(new Text_label { text = "материнская", number = 0, znach = 5 });
            TL.Add(new Text_label { text = "плата", number = 0, znach = 6 });
            TL.Add(new Text_label { text = "оперативная", number = 0, znach =7 });
            TL.Add(new Text_label { text = "память", number = 0, znach = 8 });
            TL.Add(new Text_label { text = "корневой", number = 0, znach = 9 });
            TL.Add(new Text_label { text = "каталог", number = 0, znach = 10 });
            TL.Add(new Text_label { text = "операционная", number = 0, znach = 11 });
            TL.Add(new Text_label { text = "система", number = 0, znach = 12 });
            TL.Add(new Text_label { text = "тактовая", number = 0, znach =13 });
            TL.Add(new Text_label { text = "частота", number = 0, znach = 14 });
            TL.Add(new Text_label { text = "программное", number = 0, znach = 15 });
            TL.Add(new Text_label { text = "обеспечение", number = 0, znach = 16 });
            TL.Add(new Text_label { text = "текстовый", number = 0, znach = 17 });
            TL.Add(new Text_label { text = "процессор", number = 0, znach = 18 });
            TL.Add(new Text_label { text = "жёсткий", number = 0, znach = 19 });
            TL.Add(new Text_label { text = "диск", number = 0, znach = 20 });
            TL.Add(new Text_label { text = "веб", number = 0, znach = 21 });
            TL.Add(new Text_label { text = "браузер", number = 0, znach = 22 });
            TL.Add(new Text_label { text = "база", number = 0, znach = 23 });
            TL.Add(new Text_label { text = "данных", number = 0, znach = 24 });
            TL.Add(new Text_label { text = "USB", number = 0, znach = 1 });
            TL.Add(new Text_label { text = "интерфейс", number = 0, znach = 2 });
            TL.Add(new Text_label { text = "системный", number = 0, znach = 27 });
            TL.Add(new Text_label { text = "блок", number = 0, znach =28 });
            TL.Add(new Text_label { text = "файловое", number = 0, znach =29 });
            TL.Add(new Text_label { text = "расширение", number = 0, znach = 30 });
            TL.Add(new Text_label { text = "командная", number = 0, znach = 31 });
            TL.Add(new Text_label { text = "строка", number = 0, znach = 32 });
            TL.Add(new Text_label { text = "панель", number = 0, znach = 33 });
            TL.Add(new Text_label { text = "задач", number = 0, znach = 34 });
            TL.Add(new Text_label { text = "центральный", number = 0, znach = 17 });
            TL.Add(new Text_label { text = "процессор", number = 0, znach = 18 });
            TL.Add(new Text_label { text = "системная", number = 0, znach = 37 });
            TL.Add(new Text_label { text = "шина", number = 0, znach = 38 });
            TL.Add(new Text_label { text = "интегральная", number = 0, znach = 39 });
            TL.Add(new Text_label { text = "схема", number = 0,znach = 40 });
            for(int NumberGeneration = 0; NumberGeneration <= 39;)
            {
                int massiv_number = rnd.Next(0,40);
                if(TL[massiv_number].number == 0)
                {
                    LL[NumberGeneration].label.Text = TL[massiv_number].text;
                    var mass = TL[massiv_number];
                    mass.number = 1;
                    TL[massiv_number] = mass;
                    NumberGeneration++;
                }
                else if(TL[massiv_number].number == 1)
                {

                }
            }
        
        }

        public void Label_click(int index_label)
        {
            if(text1 == null)
            {
                LL[index_label].label.BackColor = Color.Yellow;
                text1 = LL[index_label].label.Text;
                lb1 = index_label;
            }
            else if(text2 == null)
            {
                LL[index_label].label.BackColor = Color.Yellow;
                text2 = LL[index_label].label.Text;
                lb2 = index_label;
                victori();
            }

        }
        public int Point3;
        public void victori ()
        {
            if (text1 != null && text2 != null)
            {
                for(int i = 0; i < TL.Count;)
                {
                    if(text1 == TL[i].text)
                    {
                        index = i;
                        i = TL.Count;
                    }
                    else if(text1 != TL[i].text)
                    {
                        i++;
                    }
                   
                }

                for (int i = 0; i < TL.Count;)
                {
                    if (text2 == TL[i].text)
                    {
                        index2 = i;
                        i = TL.Count;
                        
                    }
                    else if (text2 != TL[i].text)
                    {
                        i++;
                    }
                }

                if ( index2 == TL[index].znach  )
                {
                    LL[lb1].label.Text = null;
                    LL[lb2].label.Text = null;
                    index = 0;
                    index2 = 0;
                    text1 = null;
                    text2 = null;
                    LL[lb1].label.BackColor = Color.Transparent;
                    LL[lb2].label.BackColor = Color.Transparent;
                    lb1 = 0;
                    lb2 = 0;

                }
                else if(index2 != TL[index].znach)
                {
                    index = 0;
                    index2 = 0;
                    text1 = null;
                    text2 = null;
                    LL[lb1].label.BackColor = Color.Transparent;
                    LL[lb2].label.BackColor = Color.Transparent;
                    lb1 = 0;
                    lb2 = 0;
                    
                }
                bool victori = true;
                for(int i=0;i<=39;i++)
                {
                    if(LL[i].label.Text != "")
                    {
                        victori = false;
                        i = 41;
                    }
                }
                if(victori ==true)
                {
                    Point3++;
                    zd3 zd = new zd3();
                    this.Hide();
                    zd.ShowDialog();
                }
            }           
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Label_click(0);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Label_click(1);
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Label_click(2);
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Label_click(3);
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Label_click(4);
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Label_click(5);
        }

        private void label7_Click(object sender, EventArgs e)
        {
            Label_click(6);
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Label_click(7);
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Label_click(8);
        }

        private void label10_Click(object sender, EventArgs e)
        {
            Label_click(9);
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Label_click(10);
        }

        private void label12_Click(object sender, EventArgs e)
        {
            Label_click(11);
        }

        private void label13_Click(object sender, EventArgs e)
        {
            Label_click(12);
        }

        private void label14_Click(object sender, EventArgs e)
        {
            Label_click(13);
        }

        private void label15_Click(object sender, EventArgs e)
        {
            Label_click(14);
        }

        private void label16_Click(object sender, EventArgs e)
        {
            Label_click(15);
        }

        private void label17_Click(object sender, EventArgs e)
        {
            Label_click(16);
        }

        private void label18_Click(object sender, EventArgs e)
        {
            Label_click(17);
        }

        private void label19_Click(object sender, EventArgs e)
        {
            Label_click(18);
        }

        private void label20_Click(object sender, EventArgs e)
        {
            Label_click(19);
        }

        private void label21_Click(object sender, EventArgs e)
        {
            Label_click(20);
        }

        private void label22_Click(object sender, EventArgs e)
        {
            Label_click(21);
        }

        private void label23_Click(object sender, EventArgs e)
        {
            Label_click(22);
        }

        private void label24_Click(object sender, EventArgs e)
        {
            Label_click(23);
        }

        private void label25_Click(object sender, EventArgs e)
        {
            Label_click(24);
        }

        private void label26_Click(object sender, EventArgs e)
        {
            Label_click(25);
        }

        private void label27_Click(object sender, EventArgs e)
        {
            Label_click(26);
        }

        private void label28_Click(object sender, EventArgs e)
        {
            Label_click(27);
        }

        private void label29_Click(object sender, EventArgs e)
        {
            Label_click(28);
        }

        private void label30_Click(object sender, EventArgs e)
        {
            Label_click(29);
        }

        private void label31_Click(object sender, EventArgs e)
        {
            Label_click(30);
        }

        private void label32_Click(object sender, EventArgs e)
        {
            Label_click(31);
        }

        private void label33_Click(object sender, EventArgs e)
        {
            Label_click(32);
        }

        private void label34_Click(object sender, EventArgs e)
        {
            Label_click(33);
        }

        private void label35_Click(object sender, EventArgs e)
        {
            Label_click(34);
        }

        private void label36_Click(object sender, EventArgs e)
        {
            Label_click(35);
        }

        private void label37_Click(object sender, EventArgs e)
        {
            Label_click(36);
        }

        private void label38_Click(object sender, EventArgs e)
        {
            Label_click(37);
        }

        private void label39_Click(object sender, EventArgs e)
        {
            Label_click(38);
        }

        private void label40_Click(object sender, EventArgs e)
        {
            Label_click(39);
        }

        private void zd3_Resize(object sender, EventArgs e)
        {
            for (int lb = 0; lb <= 39; lb++)
            {
                int width = LL[lb].label.Size.Width;
                int height = LL[lb].label.Size.Height;
                LL[lb].label.AutoSize = false;
                int newSize = (width / 2 + height / 2) / 8;
                LL[lb].label.Font = new Font(LL[lb].label.Font.Name, newSize, LL[lb].label.Font.Style);
            }
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            zd4 zd = new zd4();
            this.Hide();
            zd.ShowDialog();
        }
    }
}
