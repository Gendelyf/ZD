﻿namespace informationtest
{
    partial class zd5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.label30 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label21 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel8, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(784, 561);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel7, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel6, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(159, 115);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.60549F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.493132F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.60549F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.493132F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.60549F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.493132F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.60549F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.493132F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15.60549F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(464, 330);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.ColumnCount = 8;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37F));
            this.tableLayoutPanel7.Controls.Add(this.label40, 0, 0);
            this.tableLayoutPanel7.Controls.Add(this.label43, 3, 0);
            this.tableLayoutPanel7.Controls.Add(this.label42, 2, 0);
            this.tableLayoutPanel7.Controls.Add(this.label41, 1, 0);
            this.tableLayoutPanel7.Controls.Add(this.label44, 4, 0);
            this.tableLayoutPanel7.Controls.Add(this.label45, 5, 0);
            this.tableLayoutPanel7.Controls.Add(this.label46, 6, 0);
            this.tableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 279);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 1;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(458, 48);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label40.Location = new System.Drawing.Point(3, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(35, 48);
            this.label40.TabIndex = 16;
            this.label40.Text = "1";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label40.DragDrop += new System.Windows.Forms.DragEventHandler(this.label40_DragDrop);
            this.label40.DragEnter += new System.Windows.Forms.DragEventHandler(this.label40_DragEnter);
            this.label40.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label40_MouseDown);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label43.Location = new System.Drawing.Point(126, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(35, 48);
            this.label43.TabIndex = 19;
            this.label43.Text = "1";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label43.DragDrop += new System.Windows.Forms.DragEventHandler(this.label43_DragDrop);
            this.label43.DragEnter += new System.Windows.Forms.DragEventHandler(this.label43_DragEnter);
            this.label43.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label43_MouseDown);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label42.Location = new System.Drawing.Point(85, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(35, 48);
            this.label42.TabIndex = 18;
            this.label42.Text = "1";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label42.DragDrop += new System.Windows.Forms.DragEventHandler(this.label42_DragDrop);
            this.label42.DragEnter += new System.Windows.Forms.DragEventHandler(this.label42_DragEnter);
            this.label42.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label42_MouseDown);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label41.Location = new System.Drawing.Point(44, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(35, 48);
            this.label41.TabIndex = 17;
            this.label41.Text = "1";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label41.DragDrop += new System.Windows.Forms.DragEventHandler(this.label41_DragDrop);
            this.label41.DragEnter += new System.Windows.Forms.DragEventHandler(this.label41_DragEnter);
            this.label41.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label41_MouseDown);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label44.Location = new System.Drawing.Point(167, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(35, 48);
            this.label44.TabIndex = 20;
            this.label44.Text = "1";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label44.DragDrop += new System.Windows.Forms.DragEventHandler(this.label44_DragDrop);
            this.label44.DragEnter += new System.Windows.Forms.DragEventHandler(this.label44_DragEnter);
            this.label44.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label44_MouseDown);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label45.Location = new System.Drawing.Point(208, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(35, 48);
            this.label45.TabIndex = 21;
            this.label45.Text = "1";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label45.DragDrop += new System.Windows.Forms.DragEventHandler(this.label45_DragDrop);
            this.label45.DragEnter += new System.Windows.Forms.DragEventHandler(this.label45_DragEnter);
            this.label45.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label45_MouseDown);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label46.Location = new System.Drawing.Point(249, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(35, 48);
            this.label46.TabIndex = 22;
            this.label46.Text = "1";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label46.DragDrop += new System.Windows.Forms.DragEventHandler(this.label46_DragDrop);
            this.label46.DragEnter += new System.Windows.Forms.DragEventHandler(this.label46_DragEnter);
            this.label46.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label46_MouseDown);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 11;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel6.Controls.Add(this.label30, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.label33, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.label32, 2, 0);
            this.tableLayoutPanel6.Controls.Add(this.label31, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.label34, 4, 0);
            this.tableLayoutPanel6.Controls.Add(this.label35, 5, 0);
            this.tableLayoutPanel6.Controls.Add(this.label36, 6, 0);
            this.tableLayoutPanel6.Controls.Add(this.label37, 7, 0);
            this.tableLayoutPanel6.Controls.Add(this.label38, 8, 0);
            this.tableLayoutPanel6.Controls.Add(this.label39, 9, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 210);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 1;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(458, 45);
            this.tableLayoutPanel6.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.Location = new System.Drawing.Point(3, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(30, 45);
            this.label30.TabIndex = 16;
            this.label30.Text = "1";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.DragDrop += new System.Windows.Forms.DragEventHandler(this.label30_DragDrop);
            this.label30.DragEnter += new System.Windows.Forms.DragEventHandler(this.label30_DragEnter);
            this.label30.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label30_MouseDown);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label33.Location = new System.Drawing.Point(111, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(30, 45);
            this.label33.TabIndex = 19;
            this.label33.Text = "1";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label33.DragDrop += new System.Windows.Forms.DragEventHandler(this.label33_DragDrop);
            this.label33.DragEnter += new System.Windows.Forms.DragEventHandler(this.label33_DragEnter);
            this.label33.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label33_MouseDown);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.Location = new System.Drawing.Point(75, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(30, 45);
            this.label32.TabIndex = 18;
            this.label32.Text = "1";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label32.DragDrop += new System.Windows.Forms.DragEventHandler(this.label32_DragDrop);
            this.label32.DragEnter += new System.Windows.Forms.DragEventHandler(this.label32_DragEnter);
            this.label32.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label32_MouseDown);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.Location = new System.Drawing.Point(39, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(30, 45);
            this.label31.TabIndex = 17;
            this.label31.Text = "1";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label31.DragDrop += new System.Windows.Forms.DragEventHandler(this.label31_DragDrop);
            this.label31.DragEnter += new System.Windows.Forms.DragEventHandler(this.label31_DragEnter);
            this.label31.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label31_MouseDown);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label34.Location = new System.Drawing.Point(147, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(30, 45);
            this.label34.TabIndex = 20;
            this.label34.Text = "1";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label34.DragDrop += new System.Windows.Forms.DragEventHandler(this.label34_DragDrop);
            this.label34.DragEnter += new System.Windows.Forms.DragEventHandler(this.label34_DragEnter);
            this.label34.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label34_MouseDown);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label35.Location = new System.Drawing.Point(183, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(30, 45);
            this.label35.TabIndex = 21;
            this.label35.Text = "1";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label35.DragDrop += new System.Windows.Forms.DragEventHandler(this.label35_DragDrop);
            this.label35.DragEnter += new System.Windows.Forms.DragEventHandler(this.label35_DragEnter);
            this.label35.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label35_MouseDown);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label36.Location = new System.Drawing.Point(219, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(30, 45);
            this.label36.TabIndex = 22;
            this.label36.Text = "1";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label36.DragDrop += new System.Windows.Forms.DragEventHandler(this.label36_DragDrop);
            this.label36.DragEnter += new System.Windows.Forms.DragEventHandler(this.label36_DragEnter);
            this.label36.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label36_MouseDown);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label37.Location = new System.Drawing.Point(255, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(30, 45);
            this.label37.TabIndex = 23;
            this.label37.Text = "1";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label37.DragDrop += new System.Windows.Forms.DragEventHandler(this.label37_DragDrop);
            this.label37.DragEnter += new System.Windows.Forms.DragEventHandler(this.label37_DragEnter);
            this.label37.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label37_MouseDown);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label38.Location = new System.Drawing.Point(291, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(30, 45);
            this.label38.TabIndex = 24;
            this.label38.Text = "1";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label38.DragDrop += new System.Windows.Forms.DragEventHandler(this.label38_DragDrop);
            this.label38.DragEnter += new System.Windows.Forms.DragEventHandler(this.label38_DragEnter);
            this.label38.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label38_MouseDown);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label39.Location = new System.Drawing.Point(327, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(30, 45);
            this.label39.TabIndex = 25;
            this.label39.Text = "1";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label39.DragDrop += new System.Windows.Forms.DragEventHandler(this.label39_DragDrop);
            this.label39.DragEnter += new System.Windows.Forms.DragEventHandler(this.label39_DragEnter);
            this.label39.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label39_MouseDown);
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 10;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 9F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 19F));
            this.tableLayoutPanel5.Controls.Add(this.label21, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.label25, 4, 0);
            this.tableLayoutPanel5.Controls.Add(this.label22, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.label24, 3, 0);
            this.tableLayoutPanel5.Controls.Add(this.label23, 2, 0);
            this.tableLayoutPanel5.Controls.Add(this.label26, 5, 0);
            this.tableLayoutPanel5.Controls.Add(this.label27, 6, 0);
            this.tableLayoutPanel5.Controls.Add(this.label28, 7, 0);
            this.tableLayoutPanel5.Controls.Add(this.label29, 8, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 141);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(458, 45);
            this.tableLayoutPanel5.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(3, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 45);
            this.label21.TabIndex = 16;
            this.label21.Text = "1";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label21.DragDrop += new System.Windows.Forms.DragEventHandler(this.label21_DragDrop);
            this.label21.DragEnter += new System.Windows.Forms.DragEventHandler(this.label21_DragEnter);
            this.label21.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label21_MouseDown);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(167, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(35, 45);
            this.label25.TabIndex = 20;
            this.label25.Text = "1";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label25.DragDrop += new System.Windows.Forms.DragEventHandler(this.label25_DragDrop);
            this.label25.DragEnter += new System.Windows.Forms.DragEventHandler(this.label25_DragEnter);
            this.label25.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label25_MouseDown);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(44, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(35, 45);
            this.label22.TabIndex = 17;
            this.label22.Text = "1";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label22.DragDrop += new System.Windows.Forms.DragEventHandler(this.label22_DragDrop);
            this.label22.DragEnter += new System.Windows.Forms.DragEventHandler(this.label22_DragEnter);
            this.label22.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label22_MouseDown);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(126, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(35, 45);
            this.label24.TabIndex = 19;
            this.label24.Text = "1";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label24.DragDrop += new System.Windows.Forms.DragEventHandler(this.label24_DragDrop);
            this.label24.DragEnter += new System.Windows.Forms.DragEventHandler(this.label24_DragEnter);
            this.label24.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label24_MouseDown);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(85, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(35, 45);
            this.label23.TabIndex = 18;
            this.label23.Text = "1";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label23.DragDrop += new System.Windows.Forms.DragEventHandler(this.label23_DragDrop);
            this.label23.DragEnter += new System.Windows.Forms.DragEventHandler(this.label23_DragEnter);
            this.label23.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label23_MouseDown);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(208, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(35, 45);
            this.label26.TabIndex = 21;
            this.label26.Text = "1";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label26.DragDrop += new System.Windows.Forms.DragEventHandler(this.label26_DragDrop);
            this.label26.DragEnter += new System.Windows.Forms.DragEventHandler(this.label26_DragEnter);
            this.label26.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label26_MouseDown);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.Location = new System.Drawing.Point(249, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(35, 45);
            this.label27.TabIndex = 22;
            this.label27.Text = "1";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label27.DragDrop += new System.Windows.Forms.DragEventHandler(this.label27_DragDrop);
            this.label27.DragEnter += new System.Windows.Forms.DragEventHandler(this.label27_DragEnter);
            this.label27.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label27_MouseDown);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.Location = new System.Drawing.Point(290, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(35, 45);
            this.label28.TabIndex = 23;
            this.label28.Text = "1";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label28.DragDrop += new System.Windows.Forms.DragEventHandler(this.label28_DragDrop);
            this.label28.DragEnter += new System.Windows.Forms.DragEventHandler(this.label28_DragEnter);
            this.label28.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label28_MouseDown);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(331, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(35, 45);
            this.label29.TabIndex = 24;
            this.label29.Text = "1";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label29.DragDrop += new System.Windows.Forms.DragEventHandler(this.label29_DragDrop);
            this.label29.DragEnter += new System.Windows.Forms.DragEventHandler(this.label29_DragEnter);
            this.label29.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label29_MouseDown);
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 11;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel4.Controls.Add(this.label13, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label11, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label14, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.label15, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.label16, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.label17, 6, 0);
            this.tableLayoutPanel4.Controls.Add(this.label18, 7, 0);
            this.tableLayoutPanel4.Controls.Add(this.label19, 8, 0);
            this.tableLayoutPanel4.Controls.Add(this.label20, 9, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 72);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 1;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(458, 45);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(75, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(30, 45);
            this.label13.TabIndex = 14;
            this.label13.Text = "1";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label13.DragDrop += new System.Windows.Forms.DragEventHandler(this.label13_DragDrop);
            this.label13.DragEnter += new System.Windows.Forms.DragEventHandler(this.label13_DragEnter);
            this.label13.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label13_MouseDown);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(39, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(30, 45);
            this.label12.TabIndex = 13;
            this.label12.Text = "1";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label12.DragDrop += new System.Windows.Forms.DragEventHandler(this.label12_DragDrop);
            this.label12.DragEnter += new System.Windows.Forms.DragEventHandler(this.label12_DragEnter);
            this.label12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label12_MouseDown);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(3, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(30, 45);
            this.label11.TabIndex = 12;
            this.label11.Text = "1";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.DragDrop += new System.Windows.Forms.DragEventHandler(this.label11_DragDrop);
            this.label11.DragEnter += new System.Windows.Forms.DragEventHandler(this.label11_DragEnter);
            this.label11.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label11_MouseDown);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(111, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(30, 45);
            this.label14.TabIndex = 15;
            this.label14.Text = "1";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.DragDrop += new System.Windows.Forms.DragEventHandler(this.label14_DragDrop);
            this.label14.DragEnter += new System.Windows.Forms.DragEventHandler(this.label14_DragEnter);
            this.label14.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label14_MouseDown);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(147, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(30, 45);
            this.label15.TabIndex = 16;
            this.label15.Text = "1";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label15.DragDrop += new System.Windows.Forms.DragEventHandler(this.label15_DragDrop);
            this.label15.DragEnter += new System.Windows.Forms.DragEventHandler(this.label15_DragEnter);
            this.label15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label15_MouseDown);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(183, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(30, 45);
            this.label16.TabIndex = 17;
            this.label16.Text = "1";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label16.DragDrop += new System.Windows.Forms.DragEventHandler(this.label16_DragDrop);
            this.label16.DragEnter += new System.Windows.Forms.DragEventHandler(this.label16_DragEnter);
            this.label16.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label16_MouseDown);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(219, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(30, 45);
            this.label17.TabIndex = 18;
            this.label17.Text = "1";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label17.DragDrop += new System.Windows.Forms.DragEventHandler(this.label17_DragDrop);
            this.label17.DragEnter += new System.Windows.Forms.DragEventHandler(this.label17_DragEnter);
            this.label17.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label17_MouseDown);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(255, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(30, 45);
            this.label18.TabIndex = 19;
            this.label18.Text = "1";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label18.DragDrop += new System.Windows.Forms.DragEventHandler(this.label18_DragDrop);
            this.label18.DragEnter += new System.Windows.Forms.DragEventHandler(this.label18_DragEnter);
            this.label18.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label18_MouseDown);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(291, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(30, 45);
            this.label19.TabIndex = 20;
            this.label19.Text = "1";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label19.DragDrop += new System.Windows.Forms.DragEventHandler(this.label19_DragDrop);
            this.label19.DragEnter += new System.Windows.Forms.DragEventHandler(this.label19_DragEnter);
            this.label19.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label19_MouseDown);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(327, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(30, 45);
            this.label20.TabIndex = 21;
            this.label20.Text = "1";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label20.DragDrop += new System.Windows.Forms.DragEventHandler(this.label20_DragDrop);
            this.label20.DragEnter += new System.Windows.Forms.DragEventHandler(this.label20_DragEnter);
            this.label20.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label20_MouseDown);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 11;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel3.Controls.Add(this.label10, 9, 0);
            this.tableLayoutPanel3.Controls.Add(this.label9, 8, 0);
            this.tableLayoutPanel3.Controls.Add(this.label8, 7, 0);
            this.tableLayoutPanel3.Controls.Add(this.label7, 6, 0);
            this.tableLayoutPanel3.Controls.Add(this.label6, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.label5, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.label4, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel3.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(458, 45);
            this.tableLayoutPanel3.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(327, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(30, 45);
            this.label10.TabIndex = 20;
            this.label10.Text = "1";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label10.DragDrop += new System.Windows.Forms.DragEventHandler(this.label10_DragDrop);
            this.label10.DragEnter += new System.Windows.Forms.DragEventHandler(this.label10_DragEnter);
            this.label10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label10_MouseDown);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(291, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 45);
            this.label9.TabIndex = 19;
            this.label9.Text = "1";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.DragDrop += new System.Windows.Forms.DragEventHandler(this.label9_DragDrop);
            this.label9.DragEnter += new System.Windows.Forms.DragEventHandler(this.label9_DragEnter);
            this.label9.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label9_MouseDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(255, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 45);
            this.label8.TabIndex = 18;
            this.label8.Text = "1";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.DragDrop += new System.Windows.Forms.DragEventHandler(this.label8_DragDrop);
            this.label8.DragEnter += new System.Windows.Forms.DragEventHandler(this.label8_DragEnter);
            this.label8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label8_MouseDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(219, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 45);
            this.label7.TabIndex = 17;
            this.label7.Text = "1";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.DragDrop += new System.Windows.Forms.DragEventHandler(this.label7_DragDrop);
            this.label7.DragEnter += new System.Windows.Forms.DragEventHandler(this.label7_DragEnter);
            this.label7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label7_MouseDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(183, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(30, 45);
            this.label6.TabIndex = 16;
            this.label6.Text = "1";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.DragDrop += new System.Windows.Forms.DragEventHandler(this.label6_DragDrop);
            this.label6.DragEnter += new System.Windows.Forms.DragEventHandler(this.label6_DragEnter);
            this.label6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label6_MouseDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(147, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 45);
            this.label5.TabIndex = 15;
            this.label5.Text = "1";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.DragDrop += new System.Windows.Forms.DragEventHandler(this.label5_DragDrop);
            this.label5.DragEnter += new System.Windows.Forms.DragEventHandler(this.label5_DragEnter);
            this.label5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label5_MouseDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(111, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(30, 45);
            this.label4.TabIndex = 14;
            this.label4.Text = "1";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.DragDrop += new System.Windows.Forms.DragEventHandler(this.label4_DragDrop);
            this.label4.DragEnter += new System.Windows.Forms.DragEventHandler(this.label4_DragEnter);
            this.label4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label4_MouseDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(75, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(30, 45);
            this.label3.TabIndex = 13;
            this.label3.Text = "1";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.DragDrop += new System.Windows.Forms.DragEventHandler(this.label3_DragDrop);
            this.label3.DragEnter += new System.Windows.Forms.DragEventHandler(this.label3_DragEnter);
            this.label3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label3_MouseDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(39, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 45);
            this.label2.TabIndex = 12;
            this.label2.Text = "1";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.DragDrop += new System.Windows.Forms.DragEventHandler(this.label2_DragDrop);
            this.label2.DragEnter += new System.Windows.Forms.DragEventHandler(this.label2_DragEnter);
            this.label2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label2_MouseDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 45);
            this.label1.TabIndex = 11;
            this.label1.Text = "1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.DragDrop += new System.Windows.Forms.DragEventHandler(this.label1_DragDrop);
            this.label1.DragEnter += new System.Windows.Forms.DragEventHandler(this.label1_DragEnter);
            this.label1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label1_MouseDown);
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel8.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(159, 451);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(464, 107);
            this.tableLayoutPanel8.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(3, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(458, 26);
            this.button1.TabIndex = 0;
            this.button1.Text = "Пропустить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // zd5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 561);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "zd5";
            this.Text = "zd5";
            this.Resize += new System.EventHandler(this.zd5_Resize);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Button button1;
    }
}