﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace informationtest
{
    public partial class zd5 : Form
    {
        private struct New_label
        {
            public Label label { get; set; }
            public int sost { get; set; }
        }
        public string otw1 = "имплекация";
        public string otw2 = "магистраль";
        public string otw3 = "переферия";
        public string otw4 = "клавиатура";
        public string otw5 = "драйвер";
        List<New_label> NL = new List<New_label>();
        int label;
        string SaveText;
        public zd5() 
        {
            InitializeComponent();
            ((Control)label1).AllowDrop = true;
            ((Control)label2).AllowDrop = true;
            ((Control)label3).AllowDrop = true;
            ((Control)label4).AllowDrop = true;
            ((Control)label5).AllowDrop = true;
            ((Control)label6).AllowDrop = true;
            ((Control)label7).AllowDrop = true;
            ((Control)label8).AllowDrop = true;
            ((Control)label9).AllowDrop = true;
            ((Control)label10).AllowDrop = true;
            ((Control)label11).AllowDrop = true;
            ((Control)label12).AllowDrop = true;
            ((Control)label13).AllowDrop = true;
            ((Control)label14).AllowDrop = true;
            ((Control)label15).AllowDrop = true;
            ((Control)label16).AllowDrop = true;
            ((Control)label17).AllowDrop = true;
            ((Control)label18).AllowDrop = true;
            ((Control)label19).AllowDrop = true;
            ((Control)label20).AllowDrop = true;
            ((Control)label21).AllowDrop = true;
            ((Control)label22).AllowDrop = true;
            ((Control)label23).AllowDrop = true;
            ((Control)label24).AllowDrop = true;
            ((Control)label25).AllowDrop = true;
            ((Control)label26).AllowDrop = true;
            ((Control)label27).AllowDrop = true;
            ((Control)label28).AllowDrop = true;
            ((Control)label29).AllowDrop = true;
            ((Control)label30).AllowDrop = true;
            ((Control)label31).AllowDrop = true;
            ((Control)label32).AllowDrop = true;
            ((Control)label33).AllowDrop = true;
            ((Control)label34).AllowDrop = true;
            ((Control)label35).AllowDrop = true;
            ((Control)label36).AllowDrop = true;
            ((Control)label37).AllowDrop = true;
            ((Control)label38).AllowDrop = true;
            ((Control)label39).AllowDrop = true;
            ((Control)label40).AllowDrop = true;
            ((Control)label41).AllowDrop = true;
            ((Control)label42).AllowDrop = true;
            ((Control)label43).AllowDrop = true;
            ((Control)label44).AllowDrop = true;
            ((Control)label45).AllowDrop = true;
            ((Control)label46).AllowDrop = true;
            NL.Add(new New_label { label = label1, sost = 0});
            NL.Add(new New_label { label = label2, sost = 0 });
            NL.Add(new New_label { label = label3, sost = 0 });
            NL.Add(new New_label { label = label4, sost = 0 });
            NL.Add(new New_label { label = label5, sost = 0 });
            NL.Add(new New_label { label = label6, sost = 0 });
            NL.Add(new New_label { label = label7, sost = 0 });
            NL.Add(new New_label { label = label8, sost = 0 });
            NL.Add(new New_label { label = label9, sost = 0 });
            NL.Add(new New_label { label = label10, sost = 0 });
            NL.Add(new New_label { label = label11, sost = 0 });
            NL.Add(new New_label { label = label12, sost = 0 });
            NL.Add(new New_label { label = label13, sost = 0 });
            NL.Add(new New_label { label = label14, sost = 0 });
            NL.Add(new New_label { label = label15, sost = 0 });
            NL.Add(new New_label { label = label16, sost = 0 });
            NL.Add(new New_label { label = label17, sost = 0 });
            NL.Add(new New_label { label = label18, sost = 0 });
            NL.Add(new New_label { label = label19, sost = 0 });
            NL.Add(new New_label { label = label20, sost = 0 });
            NL.Add(new New_label { label = label21, sost = 0 });
            NL.Add(new New_label { label = label22, sost = 0 });
            NL.Add(new New_label { label = label23, sost = 0 });
            NL.Add(new New_label { label = label24, sost = 0 });
            NL.Add(new New_label { label = label25, sost = 0 });
            NL.Add(new New_label { label = label26, sost = 0 });
            NL.Add(new New_label { label = label27, sost = 0 });
            NL.Add(new New_label { label = label28, sost = 0 });
            NL.Add(new New_label { label = label29, sost = 0 });
            NL.Add(new New_label { label = label30, sost = 0 });
            NL.Add(new New_label { label = label31, sost = 0 });
            NL.Add(new New_label { label = label32, sost = 0 });
            NL.Add(new New_label { label = label33, sost = 0 });
            NL.Add(new New_label { label = label34, sost = 0 });
            NL.Add(new New_label { label = label35, sost = 0 });
            NL.Add(new New_label { label = label36, sost = 0 });
            NL.Add(new New_label { label = label37, sost = 0 });
            NL.Add(new New_label { label = label38, sost = 0 });
            NL.Add(new New_label { label = label39, sost = 0 });
            NL.Add(new New_label { label = label40, sost = 0 });
            NL.Add(new New_label { label = label41, sost = 0 });
            NL.Add(new New_label { label = label42, sost = 0 });
            NL.Add(new New_label { label = label43, sost = 0 });
            NL.Add(new New_label { label = label44, sost = 0 });
            NL.Add(new New_label { label = label45, sost = 0 });
            NL.Add(new New_label { label = label46, sost = 0 });

           List<char> ll = new List<char>();
            for (int i = 0; i < otw1.Length;i++)
            {
                    ll.Add(otw1[i]);
            }
            
            Random rand = new Random();

            for (int i = ll.Count-1; i >= 1; i--)
            {
                int j = rand.Next(i + 1);

                char tmp = ll[j];
                ll[j] = ll[i];
                ll[i] = tmp;
            }
            
            for (int i = 0; i < ll.Count; i++)
            {
                switch (i)
                {
                    case 0:
                        label1.Text = ll[i].ToString();
                        break;
                    case 1:
                        label2.Text = ll[i].ToString();
                        break;
                    case 2:
                        label3.Text = ll[i].ToString();
                        break;
                    case 3:
                        label4.Text = ll[i].ToString();
                        break;
                    case 4:
                        label5.Text = ll[i].ToString();
                        break;
                    case 5:
                        label6.Text = ll[i].ToString();
                        break;
                    case 6:
                        label7.Text = ll[i].ToString();
                        break;
                    case 7:
                        label8.Text = ll[i].ToString();
                        break;
                    case 8:
                        label9.Text = ll[i].ToString();
                        break;
                    case 9:
                        label10.Text = ll[i].ToString();
                        break;
                    default:
                        break;
                }
            }

            ll.Clear();
            for (int i = 0; i < otw2.Length; i++)
            {

                ll.Add(otw2[i]);

            }

            for (int i = ll.Count - 1; i >= 1; i--)
            {
                int j = rand.Next(i + 1);

                char tmp = ll[j];
                ll[j] = ll[i];
                ll[i] = tmp;
            }

            for (int i = 0; i < ll.Count; i++)
            {
                switch (i)
                {
                    case 0:
                        label11.Text = ll[i].ToString();
                        break;
                    case 1:
                        label12.Text = ll[i].ToString();
                        break;
                    case 2:
                        label13.Text = ll[i].ToString();
                        break;
                    case 3:
                        label14.Text = ll[i].ToString();
                        break;
                    case 4:
                        label15.Text = ll[i].ToString();
                        break;
                    case 5:
                        label16.Text = ll[i].ToString();
                        break;
                    case 6:
                        label17.Text = ll[i].ToString();
                        break;
                    case 7:
                        label18.Text = ll[i].ToString();
                        break;
                    case 8:
                        label19.Text = ll[i].ToString();
                        break;
                    case 9:
                        label20.Text = ll[i].ToString();
                        break;
                    default:
                        break;
                }
            }
            ll.Clear();
            for (int i = 0; i < otw3.Length; i++)
            {

                ll.Add(otw3[i]);

            }

            for (int i = ll.Count - 1; i >= 1; i--)
            {
                int j = rand.Next(i + 1);

                char tmp = ll[j];
                ll[j] = ll[i];
                ll[i] = tmp;
            }

            for (int i = 0; i < ll.Count; i++)
            {
                switch (i)
                {
                    case 0:
                        label21.Text = ll[i].ToString();
                        break;
                    case 1:
                        label22.Text = ll[i].ToString();
                        break;
                    case 2:
                        label23.Text = ll[i].ToString();
                        break;
                    case 3:
                        label24.Text = ll[i].ToString();
                        break;
                    case 4:
                        label25.Text = ll[i].ToString();
                        break;
                    case 5:
                        label26.Text = ll[i].ToString();
                        break;
                    case 6:
                        label27.Text = ll[i].ToString();
                        break;
                    case 7:
                        label28.Text = ll[i].ToString();
                        break;
                    case 8:
                        label29.Text = ll[i].ToString();
                        break;
                    default:
                        break;
                }
            }
            ll.Clear();
            for (int i = 0; i < otw4.Length; i++)
            {

                ll.Add(otw4[i]);

            }

            for (int i = ll.Count - 1; i >= 1; i--)
            {
                int j = rand.Next(i + 1);

                char tmp = ll[j];
                ll[j] = ll[i];
                ll[i] = tmp;
            }

            for (int i = 0; i < ll.Count; i++)
            {
                switch (i)
                {
                    case 0:
                        label30.Text = ll[i].ToString();
                        break;
                    case 1:
                        label31.Text = ll[i].ToString();
                        break;
                    case 2:
                        label32.Text = ll[i].ToString();
                        break;
                    case 3:
                        label33.Text = ll[i].ToString();
                        break;
                    case 4:
                        label34.Text = ll[i].ToString();
                        break;
                    case 5:
                        label35.Text = ll[i].ToString();
                        break;
                    case 6:
                        label36.Text = ll[i].ToString();
                        break;
                    case 7:
                        label37.Text = ll[i].ToString();
                        break;
                    case 8:
                        label38.Text = ll[i].ToString();
                        break;
                    case 9:
                        label39.Text = ll[i].ToString();
                        break;
                    default:
                        break;
                }
            }
            ll.Clear();
            for (int i = 0; i < otw5.Length; i++)
            {

                ll.Add(otw5[i]);

            }

            for (int i = ll.Count - 1; i >= 1; i--)
            {
                int j = rand.Next(i + 1);

                char tmp = ll[j];
                ll[j] = ll[i];
                ll[i] = tmp;
            }

            for (int i = 0; i < ll.Count; i++)
            {
                switch (i)
                {
                    case 0:
                        label40.Text = ll[i].ToString();
                        break;
                    case 1:
                        label41.Text = ll[i].ToString();
                        break;
                    case 2:
                        label42.Text = ll[i].ToString();
                        break;
                    case 3:
                        label43.Text = ll[i].ToString();
                        break;
                    case 4:
                        label44.Text = ll[i].ToString();
                        break;
                    case 5:
                        label45.Text = ll[i].ToString();
                        break;
                    case 6:
                        label46.Text = ll[i].ToString();
                        break;
                    default:
                        break;
                }
            }
        }

        private void zd5_Resize(object sender, EventArgs e)
        {
            for (int lb = 0; lb <= 45; lb++)
            {
                int width = NL[lb].label.Size.Width;
                int height = NL[lb].label.Size.Height;
                NL[lb].label.AutoSize = false;
                int newSize = (width / 2 + height / 2) / 2;
                NL[lb].label.Font = new Font(NL[lb].label.Font.Name, newSize, NL[lb].label.Font.Style);
            }
        }

        private void label1_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label1.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label1.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label2_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label2.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label2.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label3_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label3.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label3.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label4_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label4.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label4.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label5_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label5.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label5.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label6_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label6.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label6.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label7_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label7.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label7.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label8_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label8.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label8.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label9_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label9.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label9.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label10_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label10.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label10.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label11_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label11.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label11.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label12_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label12.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label12.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label13_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label13.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label13.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label14_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label14.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label14.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label15_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label15.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label15.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label16_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label16.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label16.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label17_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label17.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label17.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label18_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label18.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label18.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label19_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label19.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label19.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label20_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label20.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label20.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label21_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label21.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label21.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label22_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label22.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label22.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label23_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label23.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label23.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label24_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label24.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label24.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label25_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label25.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label25.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label26_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label26.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label26.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label27_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label27.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label27.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label28_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label28.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label28.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label29_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label29.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label29.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label30_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label30.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label30.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label31_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label31.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label5.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label32_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label32.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label32.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label33_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label33.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label33.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label34_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label34.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label34.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label35_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label35.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label35.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label36_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label36.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label36.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label37_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label37.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label37.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label38_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label38.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label38.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label39_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label39.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label39.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label40_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label40.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label40.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label41_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label41.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label41.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label42_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label42.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label42.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label43_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label43.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label43.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label44_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label44.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label44.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label45_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label45.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label45.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label46_DragDrop(object sender, DragEventArgs e)
        {
            SaveText = label46.Text;
            LabelNewText();
            string txt = (string)e.Data.GetData(DataFormats.Text);
            label46.Text = (string)e.Data.GetData(DataFormats.StringFormat);
            victori();
        }

        private void label1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label2_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label3_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label4_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label5_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label6_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label7_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label8_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label9_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label10_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label11_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label12_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label13_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label14_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label15_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label16_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label17_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label18_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label19_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label20_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label21_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label22_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label23_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label24_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label25_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label26_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label27_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label28_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label29_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label30_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label31_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label32_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label33_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label34_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label35_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label36_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label37_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label38_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label39_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label40_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label41_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label42_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label43_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label44_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label45_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label46_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.StringFormat) || e.Data.GetDataPresent(DataFormats.Text))
                e.Effect = DragDropEffects.Copy;
        }

        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            label = 0;
            label1.DoDragDrop(label1.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label2_MouseDown(object sender, MouseEventArgs e)
        {
            label = 1;
            label2.DoDragDrop(label2.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label3_MouseDown(object sender, MouseEventArgs e)
        {
            label = 2;
            label3.DoDragDrop(label3.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label4_MouseDown(object sender, MouseEventArgs e)
        {
            label = 3;
            label4.DoDragDrop(label4.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label5_MouseDown(object sender, MouseEventArgs e)
        {
            label = 4;
            label5.DoDragDrop(label5.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label6_MouseDown(object sender, MouseEventArgs e)
        {
            label = 5;
            label6.DoDragDrop(label6.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label7_MouseDown(object sender, MouseEventArgs e)
        {
            label = 6;
            label7.DoDragDrop(label7.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label8_MouseDown(object sender, MouseEventArgs e)
        {
            label = 7;
            label8.DoDragDrop(label8.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label9_MouseDown(object sender, MouseEventArgs e)
        {
            label = 8;
            label9.DoDragDrop(label9.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label10_MouseDown(object sender, MouseEventArgs e)
        {
            label = 9;
            label10.DoDragDrop(label10.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label11_MouseDown(object sender, MouseEventArgs e)
        {
            label = 10;
            label11.DoDragDrop(label11.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label12_MouseDown(object sender, MouseEventArgs e)
        {
            label = 11;
            label12.DoDragDrop(label12.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label13_MouseDown(object sender, MouseEventArgs e)
        {
            label = 12;
            label13.DoDragDrop(label13.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label14_MouseDown(object sender, MouseEventArgs e)
        {
            label = 13;
            label14.DoDragDrop(label14.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label15_MouseDown(object sender, MouseEventArgs e)
        {
            label = 14;
            label15.DoDragDrop(label15.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label16_MouseDown(object sender, MouseEventArgs e)
        {
            label = 15;
            label16.DoDragDrop(label16.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label17_MouseDown(object sender, MouseEventArgs e)
        {
            label = 16;
            label17.DoDragDrop(label17.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label18_MouseDown(object sender, MouseEventArgs e)
        {
            label = 17;
            label18.DoDragDrop(label18.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label19_MouseDown(object sender, MouseEventArgs e)
        {
            label = 18;
            label19.DoDragDrop(label19.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label20_MouseDown(object sender, MouseEventArgs e)
        {
            label = 19;
            label20.DoDragDrop(label20.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label21_MouseDown(object sender, MouseEventArgs e)
        {
            label = 20;
            label21.DoDragDrop(label21.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label22_MouseDown(object sender, MouseEventArgs e)
        {
            label = 21;
            label22.DoDragDrop(label22.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label23_MouseDown(object sender, MouseEventArgs e)
        {
            label = 22;
            label23.DoDragDrop(label23.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label24_MouseDown(object sender, MouseEventArgs e)
        {
            label = 23;
            label24.DoDragDrop(label24.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label25_MouseDown(object sender, MouseEventArgs e)
        {
            label = 24;
            label25.DoDragDrop(label25.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label26_MouseDown(object sender, MouseEventArgs e)
        {
            label = 25;
            label26.DoDragDrop(label26.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label27_MouseDown(object sender, MouseEventArgs e)
        {
            label = 26;
            label27.DoDragDrop(label27.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label28_MouseDown(object sender, MouseEventArgs e)
        {
            label = 27;
            label28.DoDragDrop(label28.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label29_MouseDown(object sender, MouseEventArgs e)
        {
            label = 28;
            label29.DoDragDrop(label29.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label30_MouseDown(object sender, MouseEventArgs e)
        {
            label = 29;
            label30.DoDragDrop(label30.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label31_MouseDown(object sender, MouseEventArgs e)
        {
            label = 30;
            label31.DoDragDrop(label31.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label32_MouseDown(object sender, MouseEventArgs e)
        {
            label = 31;
            label32.DoDragDrop(label32.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label33_MouseDown(object sender, MouseEventArgs e)
        {
            label = 32;
            label33.DoDragDrop(label33.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label34_MouseDown(object sender, MouseEventArgs e)
        {
            label = 33;
            label34.DoDragDrop(label34.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label35_MouseDown(object sender, MouseEventArgs e)
        {
            label = 34;
            label35.DoDragDrop(label35.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label36_MouseDown(object sender, MouseEventArgs e)
        {
            label = 35;
            label36.DoDragDrop(label36.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label37_MouseDown(object sender, MouseEventArgs e)
        {
            label = 36;
            label37.DoDragDrop(label37.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label38_MouseDown(object sender, MouseEventArgs e)
        {
            label = 37;
            label38.DoDragDrop(label38.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label39_MouseDown(object sender, MouseEventArgs e)
        {
            label = 38;
            label39.DoDragDrop(label39.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label40_MouseDown(object sender, MouseEventArgs e)
        {
            label = 39;
            label40.DoDragDrop(label40.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label41_MouseDown(object sender, MouseEventArgs e)
        {
            label = 40;
            label41.DoDragDrop(label41.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label42_MouseDown(object sender, MouseEventArgs e)
        {
            label = 41;
            label42.DoDragDrop(label42.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label43_MouseDown(object sender, MouseEventArgs e)
        {
            label = 42;
            label43.DoDragDrop(label43.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label44_MouseDown(object sender, MouseEventArgs e)
        {
            label = 43;
            label44.DoDragDrop(label44.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label45_MouseDown(object sender, MouseEventArgs e)
        {
            label = 44;
            label45.DoDragDrop(label45.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void label46_MouseDown(object sender, MouseEventArgs e)
        {
            label = 45;
            label46.DoDragDrop(label46.Text, DragDropEffects.Copy | DragDropEffects.Move);
        }
        public void LabelNewText()
        {
            NL[label].label.Text = SaveText;
        }
        public int ball;
        public int str1;
        public int str2;
        public int str3;
        public int str4;
        public int str5;
        public int point5;
        public void victori ()
        {
            string slov1 = null;
            if (str1 != 1)
            {
                for (int i = 0; i < 10; i++)
                {
                    slov1 = slov1 + $"{NL[0].label.Text}";
                }
                if (slov1 == otw1)
                {
                    for (int i = 0; i < 10; i++)
                    {
                        NL[i].label.Enabled = false;
                        ball++;
                        str1++;
                    }

                }
            }
            if (str2 != 1)
            {
                for (int i = 10; i < 19; i++)
                {
                    slov1 = slov1 + $"{NL[0].label.Text}";
                }
                if (slov1 == otw2)
                {
                    for (int i = 10; i < 19; i++)
                    {
                        NL[i].label.Enabled = false;
                        ball++;
                        str2++;
                    }

                }
            }
            if (str3 != 1)
            {
                for (int i = 20; i < 28; i++)
                {
                    slov1 = slov1 + $"{NL[0].label.Text}";
                }
                if (slov1 == otw3)
                {
                    for (int i = 20; i < 28; i++)
                    {
                        NL[i].label.Enabled = false;
                        ball++;
                        str3++;
                    }

                }
            }
            if (str4 != 1)
            {
                for (int i = 29; i < 38; i++)
                {
                    slov1 = slov1 + $"{NL[0].label.Text}";
                }
                if (slov1 == otw4)
                {
                    for (int i = 29; i < 38; i++)
                    {
                        NL[i].label.Enabled = false;
                        ball++;
                        str4++;
                    }

                }
            }
            if (str5 != 1)
            {
                for (int i = 29; i < 38; i++)
                {
                    slov1 = slov1 + $"{NL[0].label.Text}";
                }
                if (slov1 == otw5)
                {
                    for (int i = 39; i < 45; i++)
                    {
                        NL[i].label.Enabled = false;
                        ball++;
                        str5++;
                    }

                }
            }
            if(ball == 5)
            {
                point5++;
                pobeda();
            }
        }
        public int total_point;
        private void button1_Click(object sender, EventArgs e)
        {
            pobeda();
        }
        public void pobeda()
        {
            zd1 ZD1 = new zd1();
            zd2 ZD2 = new zd2();
            zd3 ZD3 = new zd3();
            zd4 ZD4 = new zd4();
             total_point = ZD1.point1 + ZD2.ball + ZD3.Point3 + ZD4.point4 + point5;
            if (total_point < 2)
            {
                total_point = 2;
            }

        }
    }
}
