﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace informationtest
{
    public partial class zd2 : Form
    {
        private struct LabelList
        {
            public Label label { get; set; }
            public int label_Pazition { get; set; }
        }
        List<LabelList> LL = new List<LabelList>();
        public zd2()
        {
            InitializeComponent();
            
            LL.Add(new LabelList { label = label1, label_Pazition =0});   
            LL.Add(new LabelList { label = label2, label_Pazition = 0 });  
            LL.Add(new LabelList { label = label3, label_Pazition = 0 });  
            LL.Add(new LabelList { label = label4, label_Pazition = 0 });  
            LL.Add(new LabelList { label = label5, label_Pazition = 0 });  
            LL.Add(new LabelList { label = label6, label_Pazition = 0 });  
            LL.Add(new LabelList { label = label7, label_Pazition = 0 });  
            LL.Add(new LabelList { label = label8, label_Pazition = 0 });  
            LL.Add(new LabelList { label = label9, label_Pazition = 0 });  
            LL.Add(new LabelList { label = label10, label_Pazition = 0 });
            LL.Add(new LabelList { label = label11, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label12, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label13, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label14, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label15, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label16, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label17, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label18, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label19, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label20, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label21, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label22, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label23, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label24, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label25, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label26, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label27, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label28, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label29, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label30, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label31, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label32, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label33, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label34, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label35, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label36, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label37, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label38, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label39, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label40, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label41, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label42, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label43, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label44, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label45, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label46, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label47, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label48, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label49, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label50, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label51, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label52, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label53, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label54, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label55, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label56, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label57, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label58, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label59, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label60, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label61, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label62, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label63, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label64, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label65, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label66, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label67, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label68, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label69, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label70, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label71, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label72, label_Pazition = 0 }); 
            LL.Add(new LabelList { label = label73, label_Pazition = 0 });
            LL.Add(new LabelList { label = label74, label_Pazition = 0 });
            LL.Add(new LabelList { label = label75, label_Pazition = 0 });
            LL.Add(new LabelList { label = label76, label_Pazition = 0 });
            LL.Add(new LabelList { label = label77, label_Pazition = 0 });
            LL.Add(new LabelList { label = label78, label_Pazition = 0 });
            LL.Add(new LabelList { label = label79, label_Pazition = 0 });
            LL.Add(new LabelList { label = label80, label_Pazition = 0 });
            LL.Add(new LabelList { label = label81, label_Pazition = 0 });
            LL.Add(new LabelList { label = label82, label_Pazition = 0 });
            LL.Add(new LabelList { label = label83, label_Pazition = 0 });
            LL.Add(new LabelList { label = label84, label_Pazition = 0 });
            LL.Add(new LabelList { label = label85, label_Pazition = 0 });
            LL.Add(new LabelList { label = label86, label_Pazition = 0 });
            LL.Add(new LabelList { label = label87, label_Pazition = 0 });
            LL.Add(new LabelList { label = label88, label_Pazition = 0 });
            LL.Add(new LabelList { label = label89, label_Pazition = 0 });
            LL.Add(new LabelList { label = label90, label_Pazition = 0 });
            LL.Add(new LabelList { label = label91, label_Pazition = 0 });
            LL.Add(new LabelList { label = label92, label_Pazition = 0 });
            LL.Add(new LabelList { label = label93, label_Pazition = 0 });
            LL.Add(new LabelList { label = label94, label_Pazition = 0 });
            LL.Add(new LabelList { label = label95, label_Pazition = 0 });
            LL.Add(new LabelList { label = label96, label_Pazition = 0 });
            LL.Add(new LabelList { label = label97, label_Pazition = 0 });
            LL.Add(new LabelList { label = label98, label_Pazition = 0 });
            LL.Add(new LabelList { label = label99, label_Pazition = 0 });
            LL.Add(new LabelList { label = label100, label_Pazition = 0 });
            LL.Add(new LabelList { label = label101, label_Pazition = 0 });
            LL.Add(new LabelList { label = label102, label_Pazition = 0 });
            LL.Add(new LabelList { label = label103, label_Pazition = 0 });
            LL.Add(new LabelList { label = label104, label_Pazition = 0 });
            LL.Add(new LabelList { label = label105, label_Pazition = 0 });
            LL.Add(new LabelList { label = label106, label_Pazition = 0 });
            LL.Add(new LabelList { label = label107, label_Pazition = 0 });
            LL.Add(new LabelList { label = label108, label_Pazition = 0 });
            LL.Add(new LabelList { label = label109, label_Pazition = 0 });
            LL.Add(new LabelList { label = label110, label_Pazition = 0 });
            LL.Add(new LabelList { label = label111, label_Pazition = 0 });
            LL.Add(new LabelList { label = label112, label_Pazition = 0 });
            LL.Add(new LabelList { label = label113, label_Pazition = 0 });
            LL.Add(new LabelList { label = label114, label_Pazition = 0 });
            LL.Add(new LabelList { label = label115, label_Pazition = 0 });
            LL.Add(new LabelList { label = label116, label_Pazition = 0 });
            LL.Add(new LabelList { label = label117, label_Pazition = 0 });
            LL.Add(new LabelList { label = label118, label_Pazition = 0 });
            LL.Add(new LabelList { label = label119, label_Pazition = 0 });
            LL.Add(new LabelList { label = label120, label_Pazition = 0 });
            LL.Add(new LabelList { label = label121, label_Pazition = 0 });
            LL.Add(new LabelList { label = label122, label_Pazition = 0 });
            LL.Add(new LabelList { label = label123, label_Pazition = 0 });
            LL.Add(new LabelList { label = label124, label_Pazition = 0 });
            LL.Add(new LabelList { label = label125, label_Pazition = 0 });
            LL.Add(new LabelList { label = label126, label_Pazition = 0 });
            LL.Add(new LabelList { label = label127, label_Pazition = 0 });
            LL.Add(new LabelList { label = label128, label_Pazition = 0 });
            LL.Add(new LabelList { label = label129, label_Pazition = 0 });
            LL.Add(new LabelList { label = label130, label_Pazition = 0 });
            LL.Add(new LabelList { label = label131, label_Pazition = 0 });
            LL.Add(new LabelList { label = label132, label_Pazition = 0 });
            LL.Add(new LabelList { label = label133, label_Pazition = 0 });
            LL.Add(new LabelList { label = label134, label_Pazition = 0 });
            LL.Add(new LabelList { label = label135, label_Pazition = 0 });
            LL.Add(new LabelList { label = label136, label_Pazition = 0 });
            LL.Add(new LabelList { label = label137, label_Pazition = 0 });
            LL.Add(new LabelList { label = label138, label_Pazition = 0 });
            LL.Add(new LabelList { label = label139, label_Pazition = 0 });
            LL.Add(new LabelList { label = label140, label_Pazition = 0 });
            LL.Add(new LabelList { label = label141, label_Pazition = 0 });
            LL.Add(new LabelList { label = label142, label_Pazition = 0 });
            LL.Add(new LabelList { label = label143, label_Pazition = 0 });
            LL.Add(new LabelList { label = label144, label_Pazition = 0 });
        }
        
        private void button1_Click(object sender, EventArgs e)
        {

            
        }

        private void zd2_Resize(object sender, EventArgs e)
        {
            for (int lb = 0; lb <= 143; lb++)
            {
                int width = LL[lb].label.Size.Width;
                int height = LL[lb].label.Size.Height;
                LL[lb].label.AutoSize = false;
                int newSize = (width / 2 + height / 2) / 2;
                LL[lb].label.Font = new Font(LL[lb].label.Font.Name, newSize, LL[lb].label.Font.Style);
            }
        }
        private void label_Click(int label_number)
        {
            if(LL[label_number].label_Pazition ==0)
            {
                LL[label_number].label.BackColor = Color.Yellow;
                var a = LL[label_number];
                a.label_Pazition = 1;
                LL[label_number] = a;

            }
            else if(LL[label_number].label_Pazition == 1)
            {
                LL[label_number].label.BackColor = Color.Transparent;
                var a = LL[label_number];
                a.label_Pazition = 0;
                LL[label_number] = a;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            label_Click(0);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            label_Click(1);
        }

        private void label3_Click(object sender, EventArgs e)
        {
            label_Click(2);
        }

        private void label4_Click(object sender, EventArgs e)
        {
            label_Click(3);
        }

        private void label5_Click(object sender, EventArgs e)
        {
            label_Click(4);
        }

        private void label6_Click(object sender, EventArgs e)
        {
            label_Click(5);
        }

        private void label7_Click(object sender, EventArgs e)
        {
            label_Click(6);
        }

        private void label8_Click(object sender, EventArgs e)
        {
            label_Click(7);
        }

        private void label9_Click(object sender, EventArgs e)
        {
            label_Click(8);
        }

        private void label10_Click(object sender, EventArgs e)
        {
            label_Click(9);
        }

        private void label11_Click(object sender, EventArgs e)
        {
            label_Click(10);
        }

        private void label12_Click(object sender, EventArgs e)
        {
            label_Click(11);
        }

        private void label13_Click(object sender, EventArgs e)
        {
            label_Click(12);
        }

        private void label14_Click(object sender, EventArgs e)
        {
            label_Click(13);
        }

        private void label15_Click(object sender, EventArgs e)
        {
            label_Click(14);
        }

        private void label16_Click(object sender, EventArgs e)
        {
            label_Click(15);
        }

        private void label17_Click(object sender, EventArgs e)
        {
            label_Click(16);
        }

        private void label18_Click(object sender, EventArgs e)
        {
            label_Click(17);
        }

        private void label19_Click(object sender, EventArgs e)
        {
            label_Click(18);
        }

        private void label20_Click(object sender, EventArgs e)
        {
            label_Click(19);
        }

        private void label21_Click(object sender, EventArgs e)
        {
            label_Click(20);
        }

        private void label22_Click(object sender, EventArgs e)
        {
            label_Click(21);
        }

        private void label23_Click(object sender, EventArgs e)
        {
            label_Click(22);
        }

        private void label24_Click(object sender, EventArgs e)
        {
            label_Click(23);
        }

        private void label25_Click(object sender, EventArgs e)
        {
            label_Click(24);
        }

        private void label26_Click(object sender, EventArgs e)
        {
            label_Click(25);
        }

        private void label27_Click(object sender, EventArgs e)
        {
            label_Click(26);
        }

        private void label28_Click(object sender, EventArgs e)
        {
            label_Click(27);
        }

        private void label29_Click(object sender, EventArgs e)
        {
            label_Click(28);
        }

        private void label30_Click(object sender, EventArgs e)
        {
            label_Click(29);
        }

        private void label31_Click(object sender, EventArgs e)
        {
            label_Click(30);
        }

        private void label32_Click(object sender, EventArgs e)
        {
            label_Click(31);
        }

        private void label33_Click(object sender, EventArgs e)
        {
            label_Click(32);
        }

        private void label34_Click(object sender, EventArgs e)
        {
            label_Click(33);
        }

        private void label35_Click(object sender, EventArgs e)
        {
            label_Click(34);
        }

        private void label36_Click(object sender, EventArgs e)
        {
            label_Click(35);
        }

        private void label37_Click(object sender, EventArgs e)
        {
            label_Click(36);
        }

        private void label38_Click(object sender, EventArgs e)
        {
            label_Click(37);
        }

        private void label39_Click(object sender, EventArgs e)
        {
            label_Click(38);
        }

        private void label40_Click(object sender, EventArgs e)
        {
            label_Click(39);
        }

        private void label41_Click(object sender, EventArgs e)
        {
            label_Click(40);
        }

        private void label42_Click(object sender, EventArgs e)
        {
            label_Click(41);
        }

        private void label43_Click(object sender, EventArgs e)
        {
            label_Click(42);
        }

        private void label44_Click(object sender, EventArgs e)
        {
            label_Click(43);
        }

        private void label45_Click(object sender, EventArgs e)
        {
            label_Click(44);
        }

        private void label46_Click(object sender, EventArgs e)
        {
            label_Click(45);
        }

        private void label47_Click(object sender, EventArgs e)
        {
            label_Click(46);
        }

        private void label48_Click(object sender, EventArgs e)
        {
            label_Click(47);
        }

        private void label49_Click(object sender, EventArgs e)
        {
            label_Click(48);
        }

        private void label50_Click(object sender, EventArgs e)
        {
            label_Click(49);
        }

        private void label51_Click(object sender, EventArgs e)
        {
            label_Click(50);
        }

        private void label52_Click(object sender, EventArgs e)
        {
            label_Click(51);
        }

        private void label53_Click(object sender, EventArgs e)
        {
            label_Click(52);
        }

        private void label54_Click(object sender, EventArgs e)
        {
            label_Click(53);
        }

        private void label55_Click(object sender, EventArgs e)
        {
            label_Click(54);
        }

        private void label56_Click(object sender, EventArgs e)
        {
            label_Click(55);
        }

        private void label57_Click(object sender, EventArgs e)
        {
            label_Click(56);
        }

        private void label58_Click(object sender, EventArgs e)
        {
            label_Click(57);
        }

        private void label59_Click(object sender, EventArgs e)
        {
            label_Click(58);
        }

        private void label60_Click(object sender, EventArgs e)
        {
            label_Click(59);
        }

        private void label61_Click(object sender, EventArgs e)
        {
            label_Click(60);
        }

        private void label62_Click(object sender, EventArgs e)
        {
            label_Click(61);
        }

        private void label63_Click(object sender, EventArgs e)
        {
            label_Click(62);
        }

        private void label64_Click(object sender, EventArgs e)
        {
            label_Click(63);
        }

        private void label65_Click(object sender, EventArgs e)
        {
            label_Click(64);
        }

        private void label66_Click(object sender, EventArgs e)
        {
            label_Click(65);
        }

        private void label67_Click(object sender, EventArgs e)
        {
            label_Click(66);
        }

        private void label68_Click(object sender, EventArgs e)
        {
            label_Click(67);
        }

        private void label69_Click(object sender, EventArgs e)
        {
            label_Click(68);
        }

        private void label70_Click(object sender, EventArgs e)
        {
            label_Click(69);
        }

        private void label71_Click(object sender, EventArgs e)
        {
            label_Click(70);
        }

        private void label72_Click(object sender, EventArgs e)
        {
            label_Click(71);
        }

        private void label73_Click(object sender, EventArgs e)
        {
            label_Click(72);
        }

        private void label74_Click(object sender, EventArgs e)
        {
            label_Click(73);
        }

        private void label75_Click(object sender, EventArgs e)
        {
            label_Click(74);
        }

        private void label76_Click(object sender, EventArgs e)
        {
            label_Click(75);
        }

        private void label77_Click(object sender, EventArgs e)
        {
            label_Click(76);
        }

        private void label78_Click(object sender, EventArgs e)
        {
            label_Click(77);
        }

        private void label79_Click(object sender, EventArgs e)
        {
            label_Click(78);
        }

        private void label80_Click(object sender, EventArgs e)
        {
            label_Click(79);
        }

        private void label81_Click(object sender, EventArgs e)
        {
            label_Click(80);
        }

        private void label82_Click(object sender, EventArgs e)
        {
            label_Click(81);
        }

        private void label83_Click(object sender, EventArgs e)
        {
            label_Click(82);
        }

        private void label84_Click(object sender, EventArgs e)
        {
            label_Click(83);
        }

        private void label85_Click(object sender, EventArgs e)
        {
            label_Click(84);
        }

        private void label86_Click(object sender, EventArgs e)
        {
            label_Click(85);
        }

        private void label87_Click(object sender, EventArgs e)
        {
            label_Click(86);
        }

        private void label88_Click(object sender, EventArgs e)
        {
            label_Click(87);
        }

        private void label89_Click(object sender, EventArgs e)
        {
            label_Click(88);
        }

        private void label90_Click(object sender, EventArgs e)
        {
            label_Click(89);
        }

        private void label91_Click(object sender, EventArgs e)
        {
            label_Click(90);
        }

        private void label92_Click(object sender, EventArgs e)
        {
            label_Click(91);
        }

        private void label93_Click(object sender, EventArgs e)
        {
            label_Click(92);
        }

        private void label94_Click(object sender, EventArgs e)
        {
            label_Click(93);
        }

        private void label95_Click(object sender, EventArgs e)
        {
            label_Click(94);
        }

        private void label96_Click(object sender, EventArgs e)
        {
            label_Click(95);
        }

        private void label97_Click(object sender, EventArgs e)
        {
            label_Click(96);
        }

        private void label98_Click(object sender, EventArgs e)
        {
            label_Click(97);
        }

        private void label99_Click(object sender, EventArgs e)
        {
            label_Click(98);
        }

        private void label100_Click(object sender, EventArgs e)
        {
            label_Click(99);
        }

        private void label101_Click(object sender, EventArgs e)
        {
            label_Click(100);
        }

        private void label102_Click(object sender, EventArgs e)
        {
            label_Click(101);
        }

        private void label103_Click(object sender, EventArgs e)
        {
            label_Click(102);
        }

        private void label104_Click(object sender, EventArgs e)
        {
            label_Click(103);
        }

        private void label105_Click(object sender, EventArgs e)
        {
            label_Click(104);
        }

        private void label106_Click(object sender, EventArgs e)
        {
            label_Click(105);
        }

        private void label107_Click(object sender, EventArgs e)
        {
            label_Click(106);
        }

        private void label108_Click(object sender, EventArgs e)
        {
            label_Click(107);
        }

        private void label109_Click(object sender, EventArgs e)
        {
            label_Click(108);
        }

        private void label110_Click(object sender, EventArgs e)
        {
            label_Click(109);
        }

        private void label111_Click(object sender, EventArgs e)
        {
            label_Click(110);
        }

        private void label112_Click(object sender, EventArgs e)
        {
            label_Click(111);
        }

        private void label113_Click(object sender, EventArgs e)
        {
            label_Click(112);
        }

        private void label114_Click(object sender, EventArgs e)
        {
            label_Click(113);
        }

        private void label115_Click(object sender, EventArgs e)
        {
            label_Click(114);
        }

        private void label116_Click(object sender, EventArgs e)
        {
            label_Click(115);
        }

        private void label117_Click(object sender, EventArgs e)
        {
            label_Click(116);
        }

        private void label118_Click(object sender, EventArgs e)
        {
            label_Click(117);
        }

        private void label119_Click(object sender, EventArgs e)
        {
            label_Click(118);
        }

        private void label120_Click(object sender, EventArgs e)
        {
            label_Click(119);
        }

        private void label121_Click(object sender, EventArgs e)
        {
            label_Click(120);
        }

        private void label122_Click(object sender, EventArgs e)
        {
            label_Click(121);
        }

        private void label123_Click(object sender, EventArgs e)
        {
            label_Click(122);
        }

        private void label124_Click(object sender, EventArgs e)
        {
            label_Click(123);
        }

        private void label125_Click(object sender, EventArgs e)
        {
            label_Click(124);
        }

        private void label126_Click(object sender, EventArgs e)
        {
            label_Click(125);
        }

        private void label127_Click(object sender, EventArgs e)
        {
            label_Click(126);
        }

        private void label128_Click(object sender, EventArgs e)
        {
            label_Click(127);
        }

        private void label129_Click(object sender, EventArgs e)
        {
            label_Click(128);
        }

        private void label130_Click(object sender, EventArgs e)
        {
            label_Click(129);
        }

        private void label131_Click(object sender, EventArgs e)
        {
            label_Click(130);
        }

        private void label132_Click(object sender, EventArgs e)
        {
            label_Click(131);
        }

        private void label133_Click(object sender, EventArgs e)
        {
            label_Click(132);
        }

        private void label134_Click(object sender, EventArgs e)
        {
            label_Click(133);
        }

        private void label135_Click(object sender, EventArgs e)
        {
            label_Click(134);
        }

        private void label136_Click(object sender, EventArgs e)
        {
            label_Click(135);
        }

        private void label137_Click(object sender, EventArgs e)
        {
            label_Click(136);
        }

        private void label138_Click(object sender, EventArgs e)
        {
            label_Click(137);
        }

        private void label139_Click(object sender, EventArgs e)
        {
            label_Click(138);
        }

        private void label140_Click(object sender, EventArgs e)
        {
            label_Click(139);
        }

        private void label141_Click(object sender, EventArgs e)
        {
            label_Click(140);
        }

        private void label142_Click(object sender, EventArgs e)
        {
            label_Click(141);
        }

        private void label143_Click(object sender, EventArgs e)
        {
            label_Click(142);
        }

        private void label144_Click(object sender, EventArgs e)
        {
            label_Click(143);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            zd3 zd = new zd3();
            this.Hide();
            zd.ShowDialog();
        }
    }
}
