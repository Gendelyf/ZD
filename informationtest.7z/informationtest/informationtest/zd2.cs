﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace informationtest
{
    public partial class zd2 : Form
    {
        public zd2()
        {
            InitializeComponent();
            
        }

        private void zd2_SizeChanged(object sender, EventArgs e)
        {
            int width = this.Width;
            int height = this.Height;
        }

        private void label1_Resize(object sender, EventArgs e)
        {
            //label1.AutoSize = false;
            //int width = label1.Size.Width;
            //int height = label1.Size.Height;
            //if (width == 54 && height == 44)
            //{
            //    label1.Font = new Font("Microsoft Sans Serif", 28, FontStyle.Regular);
            //}


        }

        private void button1_Click(object sender, EventArgs e)
        {
            lood(label1);
        }

        private void label1_SizeChanged(object sender, EventArgs e)
        {
            int width = this.Width;
            int height = this.Height;
            if (width == 800 && height == 600)
            {
                label1.Font = new Font("Microsoft Sans Serif", 16, FontStyle.Regular);
            }
            else if(width == 900 && height == 700)
            {
                
            }
            
        }
        public void lood(Label lb)
        {
            lb.BackColor = Color.White;
        }
    }
}
