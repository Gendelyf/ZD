﻿namespace informationtest
{
    partial class zd2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label144 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(604, 495);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 12;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.Controls.Add(this.label144, 11, 11);
            this.tableLayoutPanel2.Controls.Add(this.label143, 10, 11);
            this.tableLayoutPanel2.Controls.Add(this.label142, 9, 11);
            this.tableLayoutPanel2.Controls.Add(this.label141, 8, 11);
            this.tableLayoutPanel2.Controls.Add(this.label140, 7, 11);
            this.tableLayoutPanel2.Controls.Add(this.label139, 6, 11);
            this.tableLayoutPanel2.Controls.Add(this.label138, 5, 11);
            this.tableLayoutPanel2.Controls.Add(this.label137, 4, 11);
            this.tableLayoutPanel2.Controls.Add(this.label136, 3, 11);
            this.tableLayoutPanel2.Controls.Add(this.label135, 2, 11);
            this.tableLayoutPanel2.Controls.Add(this.label134, 1, 11);
            this.tableLayoutPanel2.Controls.Add(this.label133, 0, 11);
            this.tableLayoutPanel2.Controls.Add(this.label132, 11, 10);
            this.tableLayoutPanel2.Controls.Add(this.label131, 10, 10);
            this.tableLayoutPanel2.Controls.Add(this.label130, 9, 10);
            this.tableLayoutPanel2.Controls.Add(this.label129, 8, 10);
            this.tableLayoutPanel2.Controls.Add(this.label128, 7, 10);
            this.tableLayoutPanel2.Controls.Add(this.label127, 6, 10);
            this.tableLayoutPanel2.Controls.Add(this.label126, 5, 10);
            this.tableLayoutPanel2.Controls.Add(this.label125, 4, 10);
            this.tableLayoutPanel2.Controls.Add(this.label124, 3, 10);
            this.tableLayoutPanel2.Controls.Add(this.label123, 2, 10);
            this.tableLayoutPanel2.Controls.Add(this.label122, 1, 10);
            this.tableLayoutPanel2.Controls.Add(this.label121, 0, 10);
            this.tableLayoutPanel2.Controls.Add(this.label120, 11, 9);
            this.tableLayoutPanel2.Controls.Add(this.label119, 10, 9);
            this.tableLayoutPanel2.Controls.Add(this.label118, 9, 9);
            this.tableLayoutPanel2.Controls.Add(this.label117, 8, 9);
            this.tableLayoutPanel2.Controls.Add(this.label116, 7, 9);
            this.tableLayoutPanel2.Controls.Add(this.label115, 6, 9);
            this.tableLayoutPanel2.Controls.Add(this.label114, 5, 9);
            this.tableLayoutPanel2.Controls.Add(this.label113, 4, 9);
            this.tableLayoutPanel2.Controls.Add(this.label112, 3, 9);
            this.tableLayoutPanel2.Controls.Add(this.label111, 2, 9);
            this.tableLayoutPanel2.Controls.Add(this.label110, 1, 9);
            this.tableLayoutPanel2.Controls.Add(this.label109, 0, 9);
            this.tableLayoutPanel2.Controls.Add(this.label108, 11, 8);
            this.tableLayoutPanel2.Controls.Add(this.label107, 10, 8);
            this.tableLayoutPanel2.Controls.Add(this.label106, 9, 8);
            this.tableLayoutPanel2.Controls.Add(this.label105, 8, 8);
            this.tableLayoutPanel2.Controls.Add(this.label104, 7, 8);
            this.tableLayoutPanel2.Controls.Add(this.label103, 6, 8);
            this.tableLayoutPanel2.Controls.Add(this.label102, 5, 8);
            this.tableLayoutPanel2.Controls.Add(this.label101, 4, 8);
            this.tableLayoutPanel2.Controls.Add(this.label100, 3, 8);
            this.tableLayoutPanel2.Controls.Add(this.label99, 2, 8);
            this.tableLayoutPanel2.Controls.Add(this.label98, 1, 8);
            this.tableLayoutPanel2.Controls.Add(this.label97, 0, 8);
            this.tableLayoutPanel2.Controls.Add(this.label96, 11, 7);
            this.tableLayoutPanel2.Controls.Add(this.label95, 10, 7);
            this.tableLayoutPanel2.Controls.Add(this.label94, 9, 7);
            this.tableLayoutPanel2.Controls.Add(this.label93, 8, 7);
            this.tableLayoutPanel2.Controls.Add(this.label92, 7, 7);
            this.tableLayoutPanel2.Controls.Add(this.label91, 6, 7);
            this.tableLayoutPanel2.Controls.Add(this.label90, 5, 7);
            this.tableLayoutPanel2.Controls.Add(this.label89, 4, 7);
            this.tableLayoutPanel2.Controls.Add(this.label88, 3, 7);
            this.tableLayoutPanel2.Controls.Add(this.label87, 2, 7);
            this.tableLayoutPanel2.Controls.Add(this.label86, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.label85, 0, 7);
            this.tableLayoutPanel2.Controls.Add(this.label84, 11, 6);
            this.tableLayoutPanel2.Controls.Add(this.label83, 10, 6);
            this.tableLayoutPanel2.Controls.Add(this.label82, 9, 6);
            this.tableLayoutPanel2.Controls.Add(this.label81, 8, 6);
            this.tableLayoutPanel2.Controls.Add(this.label80, 7, 6);
            this.tableLayoutPanel2.Controls.Add(this.label79, 6, 6);
            this.tableLayoutPanel2.Controls.Add(this.label78, 5, 6);
            this.tableLayoutPanel2.Controls.Add(this.label77, 4, 6);
            this.tableLayoutPanel2.Controls.Add(this.label76, 3, 6);
            this.tableLayoutPanel2.Controls.Add(this.label75, 2, 6);
            this.tableLayoutPanel2.Controls.Add(this.label74, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.label73, 0, 6);
            this.tableLayoutPanel2.Controls.Add(this.label72, 11, 5);
            this.tableLayoutPanel2.Controls.Add(this.label71, 10, 5);
            this.tableLayoutPanel2.Controls.Add(this.label70, 9, 5);
            this.tableLayoutPanel2.Controls.Add(this.label69, 8, 5);
            this.tableLayoutPanel2.Controls.Add(this.label68, 7, 5);
            this.tableLayoutPanel2.Controls.Add(this.label67, 6, 5);
            this.tableLayoutPanel2.Controls.Add(this.label66, 5, 5);
            this.tableLayoutPanel2.Controls.Add(this.label65, 4, 5);
            this.tableLayoutPanel2.Controls.Add(this.label64, 3, 5);
            this.tableLayoutPanel2.Controls.Add(this.label63, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.label62, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label61, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.label60, 11, 4);
            this.tableLayoutPanel2.Controls.Add(this.label59, 10, 4);
            this.tableLayoutPanel2.Controls.Add(this.label58, 9, 4);
            this.tableLayoutPanel2.Controls.Add(this.label57, 8, 4);
            this.tableLayoutPanel2.Controls.Add(this.label56, 7, 4);
            this.tableLayoutPanel2.Controls.Add(this.label55, 6, 4);
            this.tableLayoutPanel2.Controls.Add(this.label54, 5, 4);
            this.tableLayoutPanel2.Controls.Add(this.label53, 4, 4);
            this.tableLayoutPanel2.Controls.Add(this.label52, 3, 4);
            this.tableLayoutPanel2.Controls.Add(this.label51, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.label50, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label49, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label48, 11, 3);
            this.tableLayoutPanel2.Controls.Add(this.label47, 10, 3);
            this.tableLayoutPanel2.Controls.Add(this.label46, 9, 3);
            this.tableLayoutPanel2.Controls.Add(this.label45, 8, 3);
            this.tableLayoutPanel2.Controls.Add(this.label44, 7, 3);
            this.tableLayoutPanel2.Controls.Add(this.label43, 6, 3);
            this.tableLayoutPanel2.Controls.Add(this.label42, 5, 3);
            this.tableLayoutPanel2.Controls.Add(this.label41, 4, 3);
            this.tableLayoutPanel2.Controls.Add(this.label40, 3, 3);
            this.tableLayoutPanel2.Controls.Add(this.label39, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.label38, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label37, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label36, 11, 2);
            this.tableLayoutPanel2.Controls.Add(this.label35, 10, 2);
            this.tableLayoutPanel2.Controls.Add(this.label34, 9, 2);
            this.tableLayoutPanel2.Controls.Add(this.label33, 8, 2);
            this.tableLayoutPanel2.Controls.Add(this.label32, 7, 2);
            this.tableLayoutPanel2.Controls.Add(this.label31, 6, 2);
            this.tableLayoutPanel2.Controls.Add(this.label30, 5, 2);
            this.tableLayoutPanel2.Controls.Add(this.label29, 4, 2);
            this.tableLayoutPanel2.Controls.Add(this.label28, 3, 2);
            this.tableLayoutPanel2.Controls.Add(this.label27, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.label26, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label25, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label24, 11, 1);
            this.tableLayoutPanel2.Controls.Add(this.label23, 10, 1);
            this.tableLayoutPanel2.Controls.Add(this.label22, 9, 1);
            this.tableLayoutPanel2.Controls.Add(this.label21, 8, 1);
            this.tableLayoutPanel2.Controls.Add(this.label20, 7, 1);
            this.tableLayoutPanel2.Controls.Add(this.label19, 6, 1);
            this.tableLayoutPanel2.Controls.Add(this.label18, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.label17, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.label16, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.label15, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.label14, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label13, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label12, 11, 0);
            this.tableLayoutPanel2.Controls.Add(this.label11, 10, 0);
            this.tableLayoutPanel2.Controls.Add(this.label10, 9, 0);
            this.tableLayoutPanel2.Controls.Add(this.label9, 8, 0);
            this.tableLayoutPanel2.Controls.Add(this.label8, 7, 0);
            this.tableLayoutPanel2.Controls.Add(this.label7, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.label6, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label5, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.label4, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label3, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label2, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(2, 51);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 12;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 8.333333F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(479, 442);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label144.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label144.Location = new System.Drawing.Point(431, 396);
            this.label144.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(46, 46);
            this.label144.TabIndex = 143;
            this.label144.Text = "О";
            this.label144.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label144.Click += new System.EventHandler(this.label144_Click);
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label143.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label143.Location = new System.Drawing.Point(392, 396);
            this.label143.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(35, 46);
            this.label143.TabIndex = 142;
            this.label143.Text = "В";
            this.label143.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label143.Click += new System.EventHandler(this.label143_Click);
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label142.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label142.Location = new System.Drawing.Point(353, 396);
            this.label142.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(35, 46);
            this.label142.TabIndex = 141;
            this.label142.Text = "А";
            this.label142.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label142.Click += new System.EventHandler(this.label142_Click);
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label141.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label141.Location = new System.Drawing.Point(314, 396);
            this.label141.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(35, 46);
            this.label141.TabIndex = 140;
            this.label141.Text = "Н";
            this.label141.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label141.Click += new System.EventHandler(this.label141_Click);
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label140.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label140.Location = new System.Drawing.Point(275, 396);
            this.label140.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(35, 46);
            this.label140.TabIndex = 139;
            this.label140.Text = "И";
            this.label140.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label140.Click += new System.EventHandler(this.label140_Click);
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label139.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label139.Location = new System.Drawing.Point(236, 396);
            this.label139.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(35, 46);
            this.label139.TabIndex = 138;
            this.label139.Text = "Е";
            this.label139.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label139.Click += new System.EventHandler(this.label139_Click);
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label138.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label138.Location = new System.Drawing.Point(197, 396);
            this.label138.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(35, 46);
            this.label138.TabIndex = 137;
            this.label138.Text = "Т";
            this.label138.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label138.Click += new System.EventHandler(this.label138_Click);
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label137.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label137.Location = new System.Drawing.Point(158, 396);
            this.label137.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(35, 46);
            this.label137.TabIndex = 136;
            this.label137.Text = "М";
            this.label137.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label137.Click += new System.EventHandler(this.label137_Click);
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label136.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label136.Location = new System.Drawing.Point(119, 396);
            this.label136.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(35, 46);
            this.label136.TabIndex = 135;
            this.label136.Text = "Н";
            this.label136.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label136.Click += new System.EventHandler(this.label136_Click);
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label135.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label135.Location = new System.Drawing.Point(80, 396);
            this.label135.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(35, 46);
            this.label135.TabIndex = 134;
            this.label135.Text = "Д";
            this.label135.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label135.Click += new System.EventHandler(this.label135_Click);
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label134.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label134.Location = new System.Drawing.Point(41, 396);
            this.label134.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(35, 46);
            this.label134.TabIndex = 133;
            this.label134.Text = "У";
            this.label134.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label134.Click += new System.EventHandler(this.label134_Click);
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label133.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label133.Location = new System.Drawing.Point(2, 396);
            this.label133.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(35, 46);
            this.label133.TabIndex = 132;
            this.label133.Text = "Р";
            this.label133.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label133.Click += new System.EventHandler(this.label133_Click);
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label132.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label132.Location = new System.Drawing.Point(431, 360);
            this.label132.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(46, 36);
            this.label132.TabIndex = 131;
            this.label132.Text = "Р";
            this.label132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label132.Click += new System.EventHandler(this.label132_Click);
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label131.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label131.Location = new System.Drawing.Point(392, 360);
            this.label131.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(35, 36);
            this.label131.TabIndex = 130;
            this.label131.Text = "Д";
            this.label131.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label131.Click += new System.EventHandler(this.label131_Click);
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label130.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label130.Location = new System.Drawing.Point(353, 360);
            this.label130.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(35, 36);
            this.label130.TabIndex = 129;
            this.label130.Text = "И";
            this.label130.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label130.Click += new System.EventHandler(this.label130_Click);
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label129.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label129.Location = new System.Drawing.Point(314, 360);
            this.label129.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(35, 36);
            this.label129.TabIndex = 128;
            this.label129.Text = "Т";
            this.label129.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label129.Click += new System.EventHandler(this.label129_Click);
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label128.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label128.Location = new System.Drawing.Point(275, 360);
            this.label128.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(35, 36);
            this.label128.TabIndex = 127;
            this.label128.Text = "И";
            this.label128.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label128.Click += new System.EventHandler(this.label128_Click);
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label127.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label127.Location = new System.Drawing.Point(236, 360);
            this.label127.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(35, 36);
            this.label127.TabIndex = 126;
            this.label127.Text = "В";
            this.label127.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label127.Click += new System.EventHandler(this.label127_Click);
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label126.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label126.Location = new System.Drawing.Point(197, 360);
            this.label126.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(35, 36);
            this.label126.TabIndex = 125;
            this.label126.Text = "И";
            this.label126.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label126.Click += new System.EventHandler(this.label126_Click);
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label125.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label125.Location = new System.Drawing.Point(158, 360);
            this.label125.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(35, 36);
            this.label125.TabIndex = 124;
            this.label125.Text = "К";
            this.label125.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label125.Click += new System.EventHandler(this.label125_Click);
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label124.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label124.Location = new System.Drawing.Point(119, 360);
            this.label124.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(35, 36);
            this.label124.TabIndex = 123;
            this.label124.Text = "А";
            this.label124.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label124.Click += new System.EventHandler(this.label124_Click);
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label123.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label123.Location = new System.Drawing.Point(80, 360);
            this.label123.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(35, 36);
            this.label123.TabIndex = 122;
            this.label123.Text = "А";
            this.label123.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label123.Click += new System.EventHandler(this.label123_Click);
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label122.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label122.Location = new System.Drawing.Point(41, 360);
            this.label122.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(35, 36);
            this.label122.TabIndex = 121;
            this.label122.Text = "Т";
            this.label122.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label122.Click += new System.EventHandler(this.label122_Click);
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label121.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label121.Location = new System.Drawing.Point(2, 360);
            this.label121.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(35, 36);
            this.label121.TabIndex = 120;
            this.label121.Text = "А";
            this.label121.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label121.Click += new System.EventHandler(this.label121_Click);
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label120.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label120.Location = new System.Drawing.Point(431, 324);
            this.label120.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(46, 36);
            this.label120.TabIndex = 119;
            this.label120.Text = "И ";
            this.label120.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label120.Click += new System.EventHandler(this.label120_Click);
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label119.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label119.Location = new System.Drawing.Point(392, 324);
            this.label119.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(35, 36);
            this.label119.TabIndex = 118;
            this.label119.Text = "Р";
            this.label119.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label119.Click += new System.EventHandler(this.label119_Click);
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label118.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label118.Location = new System.Drawing.Point(353, 324);
            this.label118.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(35, 36);
            this.label118.TabIndex = 117;
            this.label118.Text = "С";
            this.label118.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label118.Click += new System.EventHandler(this.label118_Click);
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label117.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label117.Location = new System.Drawing.Point(314, 324);
            this.label117.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(35, 36);
            this.label117.TabIndex = 116;
            this.label117.Text = "У";
            this.label117.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label117.Click += new System.EventHandler(this.label117_Click);
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label116.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label116.Location = new System.Drawing.Point(275, 324);
            this.label116.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(35, 36);
            this.label116.TabIndex = 115;
            this.label116.Text = "Г";
            this.label116.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label116.Click += new System.EventHandler(this.label116_Click);
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label115.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label115.Location = new System.Drawing.Point(236, 324);
            this.label115.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(35, 36);
            this.label115.TabIndex = 114;
            this.label115.Text = "О";
            this.label115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label115.Click += new System.EventHandler(this.label115_Click);
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label114.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label114.Location = new System.Drawing.Point(197, 324);
            this.label114.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(35, 36);
            this.label114.TabIndex = 113;
            this.label114.Text = "Р";
            this.label114.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label114.Click += new System.EventHandler(this.label114_Click);
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label113.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label113.Location = new System.Drawing.Point(158, 324);
            this.label113.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(35, 36);
            this.label113.TabIndex = 112;
            this.label113.Text = "О";
            this.label113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label113.Click += new System.EventHandler(this.label113_Click);
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label112.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label112.Location = new System.Drawing.Point(119, 324);
            this.label112.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(35, 36);
            this.label112.TabIndex = 111;
            this.label112.Text = "М";
            this.label112.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label112.Click += new System.EventHandler(this.label112_Click);
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label111.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label111.Location = new System.Drawing.Point(80, 324);
            this.label111.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(35, 36);
            this.label111.TabIndex = 110;
            this.label111.Text = "Е";
            this.label111.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label111.Click += new System.EventHandler(this.label111_Click);
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label110.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label110.Location = new System.Drawing.Point(41, 324);
            this.label110.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(35, 36);
            this.label110.TabIndex = 109;
            this.label110.Text = "К";
            this.label110.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label110.Click += new System.EventHandler(this.label110_Click);
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label109.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label109.Location = new System.Drawing.Point(2, 324);
            this.label109.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(35, 36);
            this.label109.TabIndex = 108;
            this.label109.Text = "Р";
            this.label109.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label109.Click += new System.EventHandler(this.label109_Click);
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label108.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label108.Location = new System.Drawing.Point(431, 288);
            this.label108.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(46, 36);
            this.label108.TabIndex = 107;
            this.label108.Text = "Т";
            this.label108.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label108.Click += new System.EventHandler(this.label108_Click);
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label107.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label107.Location = new System.Drawing.Point(392, 288);
            this.label107.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(35, 36);
            this.label107.TabIndex = 106;
            this.label107.Text = "Е";
            this.label107.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label107.Click += new System.EventHandler(this.label107_Click);
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label106.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label106.Location = new System.Drawing.Point(353, 288);
            this.label106.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(35, 36);
            this.label106.TabIndex = 105;
            this.label106.Text = "Т";
            this.label106.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label106.Click += new System.EventHandler(this.label106_Click);
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label105.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label105.Location = new System.Drawing.Point(314, 288);
            this.label105.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(35, 36);
            this.label105.TabIndex = 104;
            this.label105.Text = "Б";
            this.label105.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label105.Click += new System.EventHandler(this.label105_Click);
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label104.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label104.Location = new System.Drawing.Point(275, 288);
            this.label104.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(35, 36);
            this.label104.TabIndex = 103;
            this.label104.Text = "Л";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label104.Click += new System.EventHandler(this.label104_Click);
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label103.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label103.Location = new System.Drawing.Point(236, 288);
            this.label103.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(35, 36);
            this.label103.TabIndex = 102;
            this.label103.Text = "А";
            this.label103.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label103.Click += new System.EventHandler(this.label103_Click);
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label102.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label102.Location = new System.Drawing.Point(197, 288);
            this.label102.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(35, 36);
            this.label102.TabIndex = 101;
            this.label102.Text = "Р";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label102.Click += new System.EventHandler(this.label102_Click);
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label101.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label101.Location = new System.Drawing.Point(158, 288);
            this.label101.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(35, 36);
            this.label101.TabIndex = 100;
            this.label101.Text = "Х";
            this.label101.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label101.Click += new System.EventHandler(this.label101_Click);
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label100.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label100.Location = new System.Drawing.Point(119, 288);
            this.label100.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(35, 36);
            this.label100.TabIndex = 99;
            this.label100.Text = "И";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label100.Click += new System.EventHandler(this.label100_Click);
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label99.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label99.Location = new System.Drawing.Point(80, 288);
            this.label99.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(35, 36);
            this.label99.TabIndex = 98;
            this.label99.Text = "Т";
            this.label99.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label99.Click += new System.EventHandler(this.label99_Click);
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label98.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label98.Location = new System.Drawing.Point(41, 288);
            this.label98.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(35, 36);
            this.label98.TabIndex = 97;
            this.label98.Text = "Т";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label98.Click += new System.EventHandler(this.label98_Click);
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label97.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label97.Location = new System.Drawing.Point(2, 288);
            this.label97.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(35, 36);
            this.label97.TabIndex = 96;
            this.label97.Text = "Е";
            this.label97.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label97.Click += new System.EventHandler(this.label97_Click);
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label96.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label96.Location = new System.Drawing.Point(431, 252);
            this.label96.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(46, 36);
            this.label96.TabIndex = 95;
            this.label96.Text = "А";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label96.Click += new System.EventHandler(this.label96_Click);
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label95.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label95.Location = new System.Drawing.Point(392, 252);
            this.label95.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(35, 36);
            this.label95.TabIndex = 94;
            this.label95.Text = "Т";
            this.label95.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label95.Click += new System.EventHandler(this.label95_Click);
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label94.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label94.Location = new System.Drawing.Point(353, 252);
            this.label94.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(35, 36);
            this.label94.TabIndex = 93;
            this.label94.Text = "Р";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label94.Click += new System.EventHandler(this.label94_Click);
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label93.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label93.Location = new System.Drawing.Point(314, 252);
            this.label93.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(35, 36);
            this.label93.TabIndex = 92;
            this.label93.Text = "И";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label93.Click += new System.EventHandler(this.label93_Click);
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label92.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label92.Location = new System.Drawing.Point(275, 252);
            this.label92.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(35, 36);
            this.label92.TabIndex = 91;
            this.label92.Text = "А";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label92.Click += new System.EventHandler(this.label92_Click);
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label91.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label91.Location = new System.Drawing.Point(236, 252);
            this.label91.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(35, 36);
            this.label91.TabIndex = 90;
            this.label91.Text = "В";
            this.label91.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label91.Click += new System.EventHandler(this.label91_Click);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label90.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label90.Location = new System.Drawing.Point(197, 252);
            this.label90.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(35, 36);
            this.label90.TabIndex = 89;
            this.label90.Text = "И";
            this.label90.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label90.Click += new System.EventHandler(this.label90_Click);
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label89.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label89.Location = new System.Drawing.Point(158, 252);
            this.label89.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(35, 36);
            this.label89.TabIndex = 88;
            this.label89.Text = "Н";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label89.Click += new System.EventHandler(this.label89_Click);
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label88.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label88.Location = new System.Drawing.Point(119, 252);
            this.label88.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(35, 36);
            this.label88.TabIndex = 87;
            this.label88.Text = "Ч";
            this.label88.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label88.Click += new System.EventHandler(this.label88_Click);
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label87.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label87.Location = new System.Drawing.Point(80, 252);
            this.label87.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(35, 36);
            this.label87.TabIndex = 86;
            this.label87.Text = "Е";
            this.label87.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label87.Click += new System.EventHandler(this.label87_Click);
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label86.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label86.Location = new System.Drawing.Point(41, 252);
            this.label86.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(35, 36);
            this.label86.TabIndex = 85;
            this.label86.Text = "С";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label86.Click += new System.EventHandler(this.label86_Click);
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label85.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label85.Location = new System.Drawing.Point(2, 252);
            this.label85.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(35, 36);
            this.label85.TabIndex = 84;
            this.label85.Text = "Р";
            this.label85.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label85.Click += new System.EventHandler(this.label85_Click);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label84.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label84.Location = new System.Drawing.Point(431, 216);
            this.label84.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(46, 36);
            this.label84.TabIndex = 83;
            this.label84.Text = "М";
            this.label84.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label84.Click += new System.EventHandler(this.label84_Click);
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label83.Location = new System.Drawing.Point(392, 216);
            this.label83.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(35, 36);
            this.label83.TabIndex = 82;
            this.label83.Text = "Н";
            this.label83.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label83.Click += new System.EventHandler(this.label83_Click);
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label82.Location = new System.Drawing.Point(353, 216);
            this.label82.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(35, 36);
            this.label82.TabIndex = 81;
            this.label82.Text = "Р";
            this.label82.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label82.Click += new System.EventHandler(this.label82_Click);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label81.Location = new System.Drawing.Point(314, 216);
            this.label81.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(35, 36);
            this.label81.TabIndex = 80;
            this.label81.Text = "Т";
            this.label81.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label81.Click += new System.EventHandler(this.label81_Click);
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label80.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label80.Location = new System.Drawing.Point(275, 216);
            this.label80.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(35, 36);
            this.label80.TabIndex = 79;
            this.label80.Text = "Р";
            this.label80.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label80.Click += new System.EventHandler(this.label80_Click);
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label79.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label79.Location = new System.Drawing.Point(236, 216);
            this.label79.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(35, 36);
            this.label79.TabIndex = 78;
            this.label79.Text = "Т";
            this.label79.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label79.Click += new System.EventHandler(this.label79_Click);
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label78.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label78.Location = new System.Drawing.Point(197, 216);
            this.label78.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(35, 36);
            this.label78.TabIndex = 77;
            this.label78.Text = "Й";
            this.label78.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label78.Click += new System.EventHandler(this.label78_Click);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label77.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label77.Location = new System.Drawing.Point(158, 216);
            this.label77.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(35, 36);
            this.label77.TabIndex = 76;
            this.label77.Text = "А";
            this.label77.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label77.Click += new System.EventHandler(this.label77_Click);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label76.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label76.Location = new System.Drawing.Point(119, 216);
            this.label76.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(35, 36);
            this.label76.TabIndex = 75;
            this.label76.Text = "Б";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label76.Click += new System.EventHandler(this.label76_Click);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label75.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label75.Location = new System.Drawing.Point(80, 216);
            this.label75.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(35, 36);
            this.label75.TabIndex = 74;
            this.label75.Text = "Я";
            this.label75.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label75.Click += new System.EventHandler(this.label75_Click);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label74.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label74.Location = new System.Drawing.Point(41, 216);
            this.label74.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(35, 36);
            this.label74.TabIndex = 73;
            this.label74.Text = "Т";
            this.label74.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label74.Click += new System.EventHandler(this.label74_Click);
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label73.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label73.Location = new System.Drawing.Point(2, 216);
            this.label73.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(35, 36);
            this.label73.TabIndex = 72;
            this.label73.Text = "О";
            this.label73.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label73.Click += new System.EventHandler(this.label73_Click);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label72.Location = new System.Drawing.Point(431, 180);
            this.label72.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(46, 36);
            this.label72.TabIndex = 71;
            this.label72.Text = "Р";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label72.Click += new System.EventHandler(this.label72_Click);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label71.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label71.Location = new System.Drawing.Point(392, 180);
            this.label71.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(35, 36);
            this.label71.TabIndex = 70;
            this.label71.Text = "И";
            this.label71.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label71.Click += new System.EventHandler(this.label71_Click);
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label70.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label70.Location = new System.Drawing.Point(353, 180);
            this.label70.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(35, 36);
            this.label70.TabIndex = 69;
            this.label70.Text = "Е";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label70.Click += new System.EventHandler(this.label70_Click);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label69.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label69.Location = new System.Drawing.Point(314, 180);
            this.label69.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(35, 36);
            this.label69.TabIndex = 68;
            this.label69.Text = "И";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label69.Click += new System.EventHandler(this.label69_Click);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label68.Location = new System.Drawing.Point(275, 180);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(35, 36);
            this.label68.TabIndex = 67;
            this.label68.Text = "Е";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label68.Click += new System.EventHandler(this.label68_Click);
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label67.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label67.Location = new System.Drawing.Point(236, 180);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(35, 36);
            this.label67.TabIndex = 66;
            this.label67.Text = "В";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label67.Click += new System.EventHandler(this.label67_Click);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label66.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label66.Location = new System.Drawing.Point(197, 180);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(35, 36);
            this.label66.TabIndex = 65;
            this.label66.Text = "М";
            this.label66.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label66.Click += new System.EventHandler(this.label66_Click);
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label65.Location = new System.Drawing.Point(158, 180);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(35, 36);
            this.label65.TabIndex = 64;
            this.label65.Text = "П";
            this.label65.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label65.Click += new System.EventHandler(this.label65_Click);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label64.Location = new System.Drawing.Point(119, 180);
            this.label64.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(35, 36);
            this.label64.TabIndex = 63;
            this.label64.Text = "И";
            this.label64.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label64.Click += new System.EventHandler(this.label64_Click);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label63.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label63.Location = new System.Drawing.Point(80, 180);
            this.label63.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(35, 36);
            this.label63.TabIndex = 62;
            this.label63.Text = "Л";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label63.Click += new System.EventHandler(this.label63_Click);
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label62.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label62.Location = new System.Drawing.Point(41, 180);
            this.label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(35, 36);
            this.label62.TabIndex = 61;
            this.label62.Text = "С";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label62.Click += new System.EventHandler(this.label62_Click);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label61.Location = new System.Drawing.Point(2, 180);
            this.label61.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(35, 36);
            this.label61.TabIndex = 60;
            this.label61.Text = "У";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label61.Click += new System.EventHandler(this.label61_Click);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label60.Location = new System.Drawing.Point(431, 144);
            this.label60.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(46, 36);
            this.label60.TabIndex = 59;
            this.label60.Text = "О";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label60.Click += new System.EventHandler(this.label60_Click);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label59.Location = new System.Drawing.Point(392, 144);
            this.label59.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(35, 36);
            this.label59.TabIndex = 58;
            this.label59.Text = "Р";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label59.Click += new System.EventHandler(this.label59_Click);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label58.Location = new System.Drawing.Point(353, 144);
            this.label58.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(35, 36);
            this.label58.TabIndex = 57;
            this.label58.Text = "К";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label58.Click += new System.EventHandler(this.label58_Click);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label57.Location = new System.Drawing.Point(314, 144);
            this.label57.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(35, 36);
            this.label57.TabIndex = 56;
            this.label57.Text = "Б";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label57.Click += new System.EventHandler(this.label57_Click);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label56.Location = new System.Drawing.Point(275, 144);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(35, 36);
            this.label56.TabIndex = 55;
            this.label56.Text = "А";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label56.Click += new System.EventHandler(this.label56_Click);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label55.Location = new System.Drawing.Point(236, 144);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(35, 36);
            this.label55.TabIndex = 54;
            this.label55.Text = "Й";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label55.Click += new System.EventHandler(this.label55_Click);
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label54.Location = new System.Drawing.Point(197, 144);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(35, 36);
            this.label54.TabIndex = 53;
            this.label54.Text = "О";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label54.Click += new System.EventHandler(this.label54_Click);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label53.Location = new System.Drawing.Point(158, 144);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(35, 36);
            this.label53.TabIndex = 52;
            this.label53.Text = "Р";
            this.label53.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label53.Click += new System.EventHandler(this.label53_Click);
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label52.Location = new System.Drawing.Point(119, 144);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(35, 36);
            this.label52.TabIndex = 51;
            this.label52.Text = "Ф";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label52.Click += new System.EventHandler(this.label52_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label51.Location = new System.Drawing.Point(80, 144);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(35, 36);
            this.label51.TabIndex = 50;
            this.label51.Text = "Е";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label51.Click += new System.EventHandler(this.label51_Click);
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label50.Location = new System.Drawing.Point(41, 144);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(35, 36);
            this.label50.TabIndex = 49;
            this.label50.Text = "Д";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label50.Click += new System.EventHandler(this.label50_Click);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label49.Location = new System.Drawing.Point(2, 144);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(35, 36);
            this.label49.TabIndex = 48;
            this.label49.Text = "Р";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label49.Click += new System.EventHandler(this.label49_Click);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label48.Location = new System.Drawing.Point(431, 108);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(46, 36);
            this.label48.TabIndex = 47;
            this.label48.Text = "Ф";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label48.Click += new System.EventHandler(this.label48_Click);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label47.Location = new System.Drawing.Point(392, 108);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(35, 36);
            this.label47.TabIndex = 46;
            this.label47.Text = "П";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label47.Click += new System.EventHandler(this.label47_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label46.Location = new System.Drawing.Point(353, 108);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(35, 36);
            this.label46.TabIndex = 45;
            this.label46.Text = "А";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label46.Click += new System.EventHandler(this.label46_Click);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label45.Location = new System.Drawing.Point(314, 108);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(35, 36);
            this.label45.TabIndex = 44;
            this.label45.Text = "Х";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label45.Click += new System.EventHandler(this.label45_Click);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label44.Location = new System.Drawing.Point(275, 108);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(35, 36);
            this.label44.TabIndex = 43;
            this.label44.Text = "Р";
            this.label44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label44.Click += new System.EventHandler(this.label44_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label43.Location = new System.Drawing.Point(236, 108);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(35, 36);
            this.label43.TabIndex = 42;
            this.label43.Text = "А";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label43.Click += new System.EventHandler(this.label43_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label42.Location = new System.Drawing.Point(197, 108);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(35, 36);
            this.label42.TabIndex = 41;
            this.label42.Text = "К";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label42.Click += new System.EventHandler(this.label42_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label41.Location = new System.Drawing.Point(158, 108);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(35, 36);
            this.label41.TabIndex = 40;
            this.label41.Text = "А";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label41.Click += new System.EventHandler(this.label41_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label40.Location = new System.Drawing.Point(119, 108);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(35, 36);
            this.label40.TabIndex = 39;
            this.label40.Text = "О";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label40.Click += new System.EventHandler(this.label40_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label39.Location = new System.Drawing.Point(80, 108);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(35, 36);
            this.label39.TabIndex = 38;
            this.label39.Text = "Т";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label39.Click += new System.EventHandler(this.label39_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label38.Location = new System.Drawing.Point(41, 108);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(35, 36);
            this.label38.TabIndex = 37;
            this.label38.Text = "И";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label38.Click += new System.EventHandler(this.label38_Click);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label37.Location = new System.Drawing.Point(2, 108);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(35, 36);
            this.label37.TabIndex = 36;
            this.label37.Text = "И";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label37.Click += new System.EventHandler(this.label37_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label36.Location = new System.Drawing.Point(431, 72);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(46, 36);
            this.label36.TabIndex = 35;
            this.label36.Text = "Ш";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label36.Click += new System.EventHandler(this.label36_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label35.Location = new System.Drawing.Point(392, 72);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(35, 36);
            this.label35.TabIndex = 34;
            this.label35.Text = "К";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label35.Click += new System.EventHandler(this.label35_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label34.Location = new System.Drawing.Point(353, 72);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(35, 36);
            this.label34.TabIndex = 33;
            this.label34.Text = "А";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label33.Location = new System.Drawing.Point(314, 72);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(35, 36);
            this.label33.TabIndex = 32;
            this.label33.Text = "Т";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label32.Location = new System.Drawing.Point(275, 72);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(35, 36);
            this.label32.TabIndex = 31;
            this.label32.Text = "У";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label31.Location = new System.Drawing.Point(236, 72);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(35, 36);
            this.label31.TabIndex = 30;
            this.label31.Text = "Р";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label31.Click += new System.EventHandler(this.label31_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label30.Location = new System.Drawing.Point(197, 72);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(35, 36);
            this.label30.TabIndex = 29;
            this.label30.Text = "Д";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label29.Location = new System.Drawing.Point(158, 72);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(35, 36);
            this.label29.TabIndex = 28;
            this.label29.Text = "Г";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label28.Location = new System.Drawing.Point(119, 72);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(35, 36);
            this.label28.TabIndex = 27;
            this.label28.Text = "Р";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label28.Click += new System.EventHandler(this.label28_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label27.Location = new System.Drawing.Point(80, 72);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(35, 36);
            this.label27.TabIndex = 26;
            this.label27.Text = "Р";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label26.Location = new System.Drawing.Point(41, 72);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(35, 36);
            this.label26.TabIndex = 25;
            this.label26.Text = "Н";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label25.Location = new System.Drawing.Point(2, 72);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(35, 36);
            this.label25.TabIndex = 24;
            this.label25.Text = "В";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label24.Location = new System.Drawing.Point(431, 36);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(46, 36);
            this.label24.TabIndex = 23;
            this.label24.Text = "Ы";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label23.Location = new System.Drawing.Point(392, 36);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(35, 36);
            this.label23.TabIndex = 22;
            this.label23.Text = "А";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.Location = new System.Drawing.Point(353, 36);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(35, 36);
            this.label22.TabIndex = 21;
            this.label22.Text = "И";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.Location = new System.Drawing.Point(314, 36);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(35, 36);
            this.label21.TabIndex = 20;
            this.label21.Text = "В";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(275, 36);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(35, 36);
            this.label20.TabIndex = 19;
            this.label20.Text = "А";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(236, 36);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(35, 36);
            this.label19.TabIndex = 18;
            this.label19.Text = "Л";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.Location = new System.Drawing.Point(197, 36);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(35, 36);
            this.label18.TabIndex = 17;
            this.label18.Text = "К";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(158, 36);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 36);
            this.label17.TabIndex = 16;
            this.label17.Text = "М";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(119, 36);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 36);
            this.label16.TabIndex = 15;
            this.label16.Text = "Т";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(80, 36);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 36);
            this.label15.TabIndex = 14;
            this.label15.Text = "Е";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(41, 36);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 36);
            this.label14.TabIndex = 13;
            this.label14.Text = "О";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(2, 36);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 36);
            this.label13.TabIndex = 12;
            this.label13.Text = "М";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(431, 0);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 36);
            this.label12.TabIndex = 11;
            this.label12.Text = "М";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(392, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 36);
            this.label11.TabIndex = 10;
            this.label11.Text = "Я";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(353, 0);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 36);
            this.label10.TabIndex = 9;
            this.label10.Text = "И";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(314, 0);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 36);
            this.label9.TabIndex = 8;
            this.label9.Text = "Ц";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(275, 0);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 36);
            this.label8.TabIndex = 7;
            this.label8.Text = "А";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(236, 0);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 36);
            this.label7.TabIndex = 6;
            this.label7.Text = "Т";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(197, 0);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 36);
            this.label6.TabIndex = 5;
            this.label6.Text = "Н";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(158, 0);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 36);
            this.label5.TabIndex = 4;
            this.label5.Text = "Е";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(119, 0);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 36);
            this.label4.TabIndex = 3;
            this.label4.Text = "Т";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(80, 0);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 36);
            this.label3.TabIndex = 2;
            this.label3.Text = "О";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(41, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 36);
            this.label2.TabIndex = 1;
            this.label2.Text = "Л";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(2, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "П";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.button2, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(485, 51);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(2);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(117, 442);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button2.Location = new System.Drawing.Point(2, 68);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(113, 62);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.button1.Location = new System.Drawing.Point(2, 2);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 62);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // zd2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 495);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(604, 495);
            this.Name = "zd2";
            this.Text = "zd2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Resize += new System.EventHandler(this.zd2_Resize);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}