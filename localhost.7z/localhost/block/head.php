<html>
<header>
    <title><?php echo $row1["name"]; ?> </title>
    <link rel="stylesheet" href="../styles/style.css">
</header>
<body>
<div class="conteiner">
    <div class="head">
        <img id="dickimage" src="\block\piza2.png" style="
display: block;
width: 15%;
height: 20%;
    margin-left: 0;
    margin-right: 0;

">
    </div>