
<?php
include "block/head.php";
include "block/back.php";
$conn = mysqli_connect("localhost", "root", "root", "pizza_site");
if (!$conn) {
    die("Ошибка: " . mysqli_connect_error());
}
$sql = "SELECT id,content FROM users"; // достаю для менюхи инфу
$result = mysqli_query($conn, $sql);
If (isset($_GET["id"])){
    $id = $_GET["id"];
}
else {
    $id=1;
}
$napolnenie = "SELECT * FROM users WHERE id='$id'";
$result1 = mysqli_query($conn, $napolnenie);

$row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC);

?>
<?php

?>



    <div class="menu" style = "background-color: white">
        <?php
        echo '<center>';
        foreach($result as $row){
            echo "<a href='index.php?id=" . $row["id"] . "'>"." ".$row["content"]." ". "</a>";

        }
echo '</center>';

        ?>


    </div>

    <div class="content" style="">
        <?php echo $row1["text"]; ?>
    </div>







<?php

?>